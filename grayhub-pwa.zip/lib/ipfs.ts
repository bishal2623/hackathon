export class IPFSService {
  private static instance: IPFSService

  private constructor() {}

  static getInstance(): IPFSService {
    if (!IPFSService.instance) {
      IPFSService.instance = new IPFSService()
    }
    return IPFSService.instance
  }

  async uploadFile(file: File): Promise<string> {
    const formData = new FormData()
    formData.append("file", file)

    try {
      const response = await fetch("/api/ipfs/upload-file", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const result = await response.json()
      return result.ipfsHash
    } catch (error) {
      console.error("Error uploading to IPFS:", error)
      throw error
    }
  }

  async uploadJSON(data: object): Promise<string> {
    try {
      const response = await fetch("/api/ipfs/upload-json", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ data }),
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const result = await response.json()
      return result.ipfsHash
    } catch (error) {
      console.error("Error uploading JSON to IPFS:", error)
      throw error
    }
  }

  async encryptAndUpload(data: object, password: string): Promise<string> {
    try {
      const response = await fetch("/api/ipfs/upload-encrypted", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ data, password }),
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const result = await response.json()
      return result.ipfsHash
    } catch (error) {
      console.error("Error uploading encrypted data to IPFS:", error)
      throw error
    }
  }

  getIPFSUrl(hash: string): string {
    if (hash.startsWith("ipfs://")) {
      hash = hash.replace("ipfs://", "")
    }
    return `https://gateway.pinata.cloud/ipfs/${hash}`
  }
}

export const ipfsService = IPFSService.getInstance()
