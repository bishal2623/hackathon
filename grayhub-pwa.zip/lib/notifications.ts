export class NotificationService {
  private static instance: NotificationService
  private registration: ServiceWorkerRegistration | null = null

  private constructor() {}

  static getInstance(): NotificationService {
    if (!NotificationService.instance) {
      NotificationService.instance = new NotificationService()
    }
    return NotificationService.instance
  }

  async initialize(): Promise<boolean> {
    if (!("serviceWorker" in navigator) || !("PushManager" in window)) {
      console.warn("Push messaging is not supported")
      return false
    }

    try {
      this.registration = await navigator.serviceWorker.ready
      return true
    } catch (error) {
      console.error("Service Worker registration failed:", error)
      return false
    }
  }

  async requestPermission(): Promise<boolean> {
    if (!("Notification" in window)) {
      console.warn("This browser does not support notifications")
      return false
    }

    if (Notification.permission === "granted") {
      return true
    }

    if (Notification.permission !== "denied") {
      const permission = await Notification.requestPermission()
      return permission === "granted"
    }

    return false
  }

  async subscribeUser(): Promise<PushSubscription | null> {
    if (!this.registration) {
      await this.initialize()
    }

    if (!this.registration) {
      return null
    }

    try {
      const subscription = await this.registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY,
      })

      return subscription
    } catch (error) {
      console.error("Failed to subscribe user:", error)
      return null
    }
  }

  async showNotification(title: string, options: NotificationOptions = {}): Promise<void> {
    if (!this.registration) {
      await this.initialize()
    }

    if (this.registration && Notification.permission === "granted") {
      await this.registration.showNotification(title, {
        icon: "/icons/icon-192x192.jpg",
        badge: "/icons/icon-192x192.jpg",
        ...options,
      })
    }
  }

  // Mock notification triggers for demo purposes
  async triggerNFTMintNotification(projectName: string): Promise<void> {
    await this.showNotification("NFT Minted Successfully! 🎉", {
      body: `Your project "${projectName}" has been minted as an NFT`,
      tag: "nft-mint",
      requireInteraction: true,
      actions: [
        { action: "view", title: "View NFT" },
        { action: "share", title: "Share" },
      ],
    })
  }

  async triggerNDARequestNotification(requesterName: string): Promise<void> {
    await this.showNotification("New NDA Request 📋", {
      body: `${requesterName} has requested access to your private project`,
      tag: "nda-request",
      requireInteraction: true,
      actions: [
        { action: "approve", title: "Approve" },
        { action: "deny", title: "Deny" },
      ],
    })
  }

  async triggerPatentScoreUpdateNotification(projectName: string, score: number): Promise<void> {
    await this.showNotification("Patent Score Updated 📊", {
      body: `${projectName} received a patent score of ${score}/100`,
      tag: "patent-score",
      actions: [{ action: "view", title: "View Details" }],
    })
  }

  async triggerMentorFeedbackNotification(mentorName: string): Promise<void> {
    await this.showNotification("New Mentor Feedback 💬", {
      body: `${mentorName} has provided feedback on your project`,
      tag: "mentor-feedback",
      actions: [{ action: "view", title: "Read Feedback" }],
    })
  }
}

export const notificationService = NotificationService.getInstance()
