import { neon } from "@neondatabase/serverless"

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL environment variable is required")
}

export const sql = neon(process.env.DATABASE_URL)

// Database helper functions
export async function createUser(userData: {
  walletAddress: string
  email?: string
  username?: string
  displayName?: string
}) {
  const [user] = await sql`
    INSERT INTO users (wallet_address, email, username, display_name)
    VALUES (${userData.walletAddress}, ${userData.email}, ${userData.username}, ${userData.displayName})
    ON CONFLICT (wallet_address) DO UPDATE SET
      email = COALESCE(EXCLUDED.email, users.email),
      username = COALESCE(EXCLUDED.username, users.username),
      display_name = COALESCE(EXCLUDED.display_name, users.display_name),
      updated_at = NOW()
    RETURNING *
  `
  return user
}

export async function getUserByWallet(walletAddress: string) {
  const [user] = await sql`
    SELECT * FROM users WHERE wallet_address = ${walletAddress}
  `
  return user
}

export async function createProject(projectData: {
  creatorId: string
  title: string
  description: string
  category: string
  tags: string[]
}) {
  const [project] = await sql`
    INSERT INTO projects (creator_id, title, description, category, tags)
    VALUES (${projectData.creatorId}, ${projectData.title}, ${projectData.description}, 
            ${projectData.category}, ${projectData.tags})
    RETURNING *
  `
  return project
}

export async function getProjectsByUser(userId: string) {
  return await sql`
    SELECT p.*, u.username as creator_username, u.display_name as creator_name
    FROM projects p
    JOIN users u ON p.creator_id = u.id
    WHERE p.creator_id = ${userId}
    ORDER BY p.created_at DESC
  `
}

export async function logSecurityEvent(eventData: {
  userId?: string
  action: string
  resourceType?: string
  resourceId?: string
  ipAddress?: string
  userAgent?: string
  riskScore?: number
  metadata?: any
}) {
  await sql`
    INSERT INTO security_logs (user_id, action, resource_type, resource_id, ip_address, user_agent, risk_score, metadata)
    VALUES (${eventData.userId}, ${eventData.action}, ${eventData.resourceType}, 
            ${eventData.resourceId}, ${eventData.ipAddress}, ${eventData.userAgent}, 
            ${eventData.riskScore || 0}, ${JSON.stringify(eventData.metadata || {})})
  `
}
