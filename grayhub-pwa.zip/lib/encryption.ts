import { createCipheriv, createDecipheriv, randomBytes, scrypt } from "crypto"
import { promisify } from "util"

const scryptAsync = promisify(scrypt)

export class EncryptionService {
  private static readonly ALGORITHM = "aes-256-gcm"
  private static readonly KEY_LENGTH = 32
  private static readonly IV_LENGTH = 16
  private static readonly TAG_LENGTH = 16

  // Derive key from password using scrypt
  private static async deriveKey(password: string, salt: Buffer): Promise<Buffer> {
    return (await scryptAsync(password, salt, EncryptionService.KEY_LENGTH)) as Buffer
  }

  // Encrypt sensitive data
  static async encrypt(data: string, password: string): Promise<string> {
    try {
      const salt = randomBytes(32)
      const iv = randomBytes(EncryptionService.IV_LENGTH)
      const key = await EncryptionService.deriveKey(password, salt)

      const cipher = createCipheriv(EncryptionService.ALGORITHM, key, iv)

      let encrypted = cipher.update(data, "utf8", "hex")
      encrypted += cipher.final("hex")

      const tag = cipher.getAuthTag()

      // Combine salt + iv + tag + encrypted data
      const result = Buffer.concat([salt, iv, tag, Buffer.from(encrypted, "hex")])

      return result.toString("base64")
    } catch (error) {
      throw new Error("Encryption failed")
    }
  }

  // Decrypt sensitive data
  static async decrypt(encryptedData: string, password: string): Promise<string> {
    try {
      const data = Buffer.from(encryptedData, "base64")

      const salt = data.subarray(0, 32)
      const iv = data.subarray(32, 32 + EncryptionService.IV_LENGTH)
      const tag = data.subarray(
        32 + EncryptionService.IV_LENGTH,
        32 + EncryptionService.IV_LENGTH + EncryptionService.TAG_LENGTH,
      )
      const encrypted = data.subarray(32 + EncryptionService.IV_LENGTH + EncryptionService.TAG_LENGTH)

      const key = await EncryptionService.deriveKey(password, salt)

      const decipher = createDecipheriv(EncryptionService.ALGORITHM, key, iv)
      decipher.setAuthTag(tag)

      let decrypted = decipher.update(encrypted, undefined, "utf8")
      decrypted += decipher.final("utf8")

      return decrypted
    } catch (error) {
      throw new Error("Decryption failed")
    }
  }

  // Generate secure random token
  static generateSecureToken(length = 32): string {
    return randomBytes(length).toString("hex")
  }

  // Hash sensitive data (one-way)
  static async hashData(data: string): Promise<string> {
    const salt = randomBytes(32)
    const key = await EncryptionService.deriveKey(data, salt)
    return Buffer.concat([salt, key]).toString("base64")
  }

  // Verify hashed data
  static async verifyHash(data: string, hash: string): Promise<boolean> {
    try {
      const hashBuffer = Buffer.from(hash, "base64")
      const salt = hashBuffer.subarray(0, 32)
      const storedKey = hashBuffer.subarray(32)

      const derivedKey = await EncryptionService.deriveKey(data, salt)

      return storedKey.equals(derivedKey)
    } catch (error) {
      return false
    }
  }
}
