import { getDefaultConfig } from "@rainbow-me/rainbowkit"
import {
  mainnet,
  polygon,
  optimism,
  arbitrum,
  base,
  sepolia,
  polygonMumbai,
  optimismGoerli,
  arbitrumGoerli,
  baseGoerli,
} from "wagmi/chains"

export const config = getDefaultConfig({
  appName: "GrayHub",
  projectId: process.env.NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID || "default-project-id",
  chains: [
    mainnet,
    polygon,
    optimism,
    arbitrum,
    base,
    ...(process.env.NODE_ENV === "development"
      ? [sepolia, polygonMumbai, optimismGoerli, arbitrumGoerli, baseGoerli]
      : []),
  ],
  ssr: true,
})

// Contract addresses for different chains
export const CONTRACT_ADDRESSES = {
  [mainnet.id]: {
    nftContract: "0x...",
    marketplace: "0x...",
  },
  [polygon.id]: {
    nftContract: "0x...",
    marketplace: "0x...",
  },
  [optimism.id]: {
    nftContract: "0x...",
    marketplace: "0x...",
  },
  [arbitrum.id]: {
    nftContract: "0x...",
    marketplace: "0x...",
  },
  [base.id]: {
    nftContract: "0x...",
    marketplace: "0x...",
  },
} as const

// NFT Contract ABI (simplified)
export const NFT_CONTRACT_ABI = [
  {
    inputs: [
      { name: "to", type: "address" },
      { name: "tokenURI", type: "string" },
      { name: "projectData", type: "bytes" },
    ],
    name: "mintProject",
    outputs: [{ name: "tokenId", type: "uint256" }],
    stateMutability: "payable",
    type: "function",
  },
  {
    inputs: [{ name: "tokenId", type: "uint256" }],
    name: "tokenURI",
    outputs: [{ name: "", type: "string" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [{ name: "owner", type: "address" }],
    name: "balanceOf",
    outputs: [{ name: "", type: "uint256" }],
    stateMutability: "view",
    type: "function",
  },
] as const

// Marketplace Contract ABI (simplified)
export const MARKETPLACE_CONTRACT_ABI = [
  {
    inputs: [
      { name: "tokenId", type: "uint256" },
      { name: "price", type: "uint256" },
    ],
    name: "listProject",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [{ name: "tokenId", type: "uint256" }],
    name: "buyProject",
    outputs: [],
    stateMutability: "payable",
    type: "function",
  },
] as const

// Chain configuration
export const SUPPORTED_CHAINS = {
  ethereum: {
    id: mainnet.id,
    name: "Ethereum",
    color: "#627EEA",
    icon: "⟠",
  },
  polygon: {
    id: polygon.id,
    name: "Polygon",
    color: "#8247E5",
    icon: "⬟",
  },
  optimism: {
    id: optimism.id,
    name: "Optimism",
    color: "#FF0420",
    icon: "🔴",
  },
  arbitrum: {
    id: arbitrum.id,
    name: "Arbitrum",
    color: "#28A0F0",
    icon: "🔵",
  },
  base: {
    id: base.id,
    name: "Base",
    color: "#0052FF",
    icon: "🔷",
  },
} as const

export type SupportedChain = keyof typeof SUPPORTED_CHAINS
