import type { NextRequest } from "next/server"
import { sql } from "./database"
import { EncryptionService } from "./encryption"

export interface SecurityConfig {
  maxLoginAttempts: number
  lockoutDuration: number // minutes
  sessionTimeout: number // minutes
  requireMFA: boolean
  allowedOrigins: string[]
  rateLimitWindow: number // minutes
  rateLimitMax: number
}

export const defaultSecurityConfig: SecurityConfig = {
  maxLoginAttempts: 5,
  lockoutDuration: 30,
  sessionTimeout: 60,
  requireMFA: false,
  allowedOrigins: ["http://localhost:3000", "https://grayhub.app"],
  rateLimitWindow: 15,
  rateLimitMax: 100,
}

export class SecurityService {
  // Rate limiting
  static async checkRateLimit(
    identifier: string,
    action: string,
    config: SecurityConfig = defaultSecurityConfig,
  ): Promise<{ allowed: boolean; remaining: number; resetTime: Date }> {
    const windowStart = new Date(Date.now() - config.rateLimitWindow * 60 * 1000)

    const [result] = await sql`
      SELECT COUNT(*) as attempts
      FROM security_logs
      WHERE (ip_address = ${identifier} OR user_id = ${identifier})
      AND action = ${action}
      AND created_at > ${windowStart}
    `

    const attempts = Number.parseInt(result?.attempts || "0")
    const remaining = Math.max(0, config.rateLimitMax - attempts)
    const resetTime = new Date(Date.now() + config.rateLimitWindow * 60 * 1000)

    return {
      allowed: attempts < config.rateLimitMax,
      remaining,
      resetTime,
    }
  }

  // Account lockout management
  static async checkAccountLockout(userId: string): Promise<{ locked: boolean; unlockTime?: Date }> {
    const [lockout] = await sql`
      SELECT locked_until
      FROM user_lockouts
      WHERE user_id = ${userId}
      AND locked_until > NOW()
    `

    if (lockout) {
      return {
        locked: true,
        unlockTime: new Date(lockout.locked_until),
      }
    }

    return { locked: false }
  }

  static async lockAccount(userId: string, duration = 30): Promise<void> {
    const unlockTime = new Date(Date.now() + duration * 60 * 1000)

    await sql`
      INSERT INTO user_lockouts (user_id, locked_until, reason)
      VALUES (${userId}, ${unlockTime}, 'excessive_failed_attempts')
      ON CONFLICT (user_id) DO UPDATE SET
        locked_until = ${unlockTime},
        attempt_count = user_lockouts.attempt_count + 1
    `
  }

  // Input validation and sanitization
  static sanitizeInput(input: string): string {
    return input
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "")
      .replace(/javascript:/gi, "")
      .replace(/on\w+\s*=/gi, "")
      .trim()
  }

  static validateCSRF(request: NextRequest, sessionToken: string): boolean {
    const csrfToken = request.headers.get("x-csrf-token")
    const expectedToken = EncryptionService.generateSecureToken(16)

    // In production, store CSRF tokens in session
    return csrfToken === expectedToken
  }

  // Content Security Policy
  static getCSPHeader(): string {
    return [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdn.jsdelivr.net",
      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
      "font-src 'self' https://fonts.gstatic.com",
      "img-src 'self' data: https: blob:",
      "connect-src 'self' https://api.pinata.cloud https://gateway.pinata.cloud",
      "frame-ancestors 'none'",
      "base-uri 'self'",
      "form-action 'self'",
    ].join("; ")
  }

  // Security headers
  static getSecurityHeaders(): Record<string, string> {
    return {
      "Content-Security-Policy": SecurityService.getCSPHeader(),
      "X-Frame-Options": "DENY",
      "X-Content-Type-Options": "nosniff",
      "Referrer-Policy": "strict-origin-when-cross-origin",
      "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
      "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
      "X-XSS-Protection": "1; mode=block",
    }
  }

  // Audit logging with risk scoring
  static async logSecurityEvent(eventData: {
    userId?: string
    action: string
    resourceType?: string
    resourceId?: string
    ipAddress?: string
    userAgent?: string
    success: boolean
    riskFactors?: string[]
    metadata?: any
  }): Promise<void> {
    let riskScore = 0

    // Calculate risk score based on factors
    if (eventData.riskFactors) {
      eventData.riskFactors.forEach((factor) => {
        switch (factor) {
          case "unusual_location":
            riskScore += 20
            break
          case "new_device":
            riskScore += 15
            break
          case "multiple_failures":
            riskScore += 25
            break
          case "suspicious_timing":
            riskScore += 10
            break
          case "privilege_escalation":
            riskScore += 30
            break
          default:
            riskScore += 5
        }
      })
    }

    if (!eventData.success) riskScore += 10

    await sql`
      INSERT INTO security_logs (
        user_id, action, resource_type, resource_id, ip_address, 
        user_agent, risk_score, metadata
      )
      VALUES (
        ${eventData.userId}, ${eventData.action}, ${eventData.resourceType},
        ${eventData.resourceId}, ${eventData.ipAddress}, ${eventData.userAgent},
        ${Math.min(riskScore, 100)}, ${JSON.stringify(eventData.metadata || {})}
      )
    `

    // Trigger alerts for high-risk events
    if (riskScore > 70) {
      await SecurityService.triggerSecurityAlert(eventData, riskScore)
    }
  }

  private static async triggerSecurityAlert(eventData: any, riskScore: number): Promise<void> {
    // In production, send alerts via email/Slack/etc.
    console.warn(`[SECURITY ALERT] High-risk event detected:`, {
      action: eventData.action,
      userId: eventData.userId,
      riskScore,
      timestamp: new Date().toISOString(),
    })
  }
}
