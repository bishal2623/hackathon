import { createHash, randomBytes } from "crypto"
import { sql } from "./database"
import { logSecurityEvent } from "./database"

export interface AuthSession {
  id: string
  userId: string
  sessionToken: string
  expiresAt: Date
}

export async function createSession(
  userId: string,
  walletSignature: string,
  ipAddress?: string,
  userAgent?: string,
): Promise<AuthSession> {
  const sessionToken = randomBytes(32).toString("hex")
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days

  // Create device fingerprint
  const deviceFingerprint = createHash("sha256")
    .update(`${userAgent || ""}${ipAddress || ""}`)
    .digest("hex")

  const [session] = await sql`
    INSERT INTO user_sessions (user_id, session_token, wallet_signature, ip_address, user_agent, device_fingerprint, expires_at)
    VALUES (${userId}, ${sessionToken}, ${walletSignature}, ${ipAddress}, ${userAgent}, ${deviceFingerprint}, ${expiresAt})
    RETURNING id, user_id, session_token, expires_at
  `

  // Log security event
  await logSecurityEvent({
    userId,
    action: "session_created",
    ipAddress,
    userAgent,
    riskScore: 0,
    metadata: { deviceFingerprint },
  })

  return {
    id: session.id,
    userId: session.user_id,
    sessionToken: session.session_token,
    expiresAt: new Date(session.expires_at),
  }
}

export async function validateSession(sessionToken: string): Promise<AuthSession | null> {
  const [session] = await sql`
    SELECT s.*, u.wallet_address
    FROM user_sessions s
    JOIN users u ON s.user_id = u.id
    WHERE s.session_token = ${sessionToken} 
    AND s.expires_at > NOW()
  `

  if (!session) return null

  // Update last accessed
  await sql`
    UPDATE user_sessions 
    SET last_accessed_at = NOW() 
    WHERE session_token = ${sessionToken}
  `

  return {
    id: session.id,
    userId: session.user_id,
    sessionToken: session.session_token,
    expiresAt: new Date(session.expires_at),
  }
}

export async function revokeSession(sessionToken: string): Promise<void> {
  const [session] = await sql`
    DELETE FROM user_sessions 
    WHERE session_token = ${sessionToken}
    RETURNING user_id
  `

  if (session) {
    await logSecurityEvent({
      userId: session.user_id,
      action: "session_revoked",
      metadata: { sessionToken: sessionToken.substring(0, 8) + "..." },
    })
  }
}

export async function detectSuspiciousActivity(userId: string, ipAddress?: string): Promise<number> {
  // Check for multiple failed attempts
  const recentFailures = await sql`
    SELECT COUNT(*) as count
    FROM security_logs
    WHERE user_id = ${userId}
    AND action LIKE '%_failed'
    AND created_at > NOW() - INTERVAL '1 hour'
  `

  // Check for unusual IP patterns
  const ipChanges = await sql`
    SELECT COUNT(DISTINCT ip_address) as unique_ips
    FROM security_logs
    WHERE user_id = ${userId}
    AND created_at > NOW() - INTERVAL '24 hours'
  `

  let riskScore = 0
  if (recentFailures[0]?.count > 3) riskScore += 30
  if (ipChanges[0]?.unique_ips > 5) riskScore += 20

  return Math.min(riskScore, 100)
}
