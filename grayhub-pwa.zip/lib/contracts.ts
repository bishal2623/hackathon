import { useReadContract, useWriteContract, useWaitForTransactionReceipt } from "wagmi"
import { parseEther } from "viem"
import { CONTRACT_ADDRESSES, NFT_CONTRACT_ABI, MARKETPLACE_CONTRACT_ABI } from "./web3"
import { ipfsService } from "./ipfs"

export interface ProjectMetadata {
  name: string
  description: string
  image: string
  attributes: Array<{
    trait_type: string
    value: string | number
  }>
  external_url?: string
  animation_url?: string
}

export interface ProjectData {
  title: string
  description: string
  category: string
  author: string
  files: File[]
  isPrivate: boolean
  collaborators?: string[]
  tags: string[]
}

// Hook for minting NFTs
export function useMintProject() {
  const { writeContract, data: hash, isPending, error } = useWriteContract()
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({
    hash,
  })

  const mintProject = async (projectData: ProjectData, chainId: number) => {
    try {
      // Upload files to IPFS
      const fileHashes = await Promise.all(projectData.files.map((file) => ipfsService.uploadFile(file)))

      // Create metadata
      const metadata: ProjectMetadata = {
        name: projectData.title,
        description: projectData.description,
        image: fileHashes[0] || "", // Use first file as main image
        attributes: [
          { trait_type: "Category", value: projectData.category },
          { trait_type: "Author", value: projectData.author },
          { trait_type: "Privacy", value: projectData.isPrivate ? "Private" : "Public" },
          { trait_type: "File Count", value: projectData.files.length },
          ...projectData.tags.map((tag) => ({ trait_type: "Tag", value: tag })),
        ],
        external_url: `https://grayhub.vercel.app/projects/${Date.now()}`,
      }

      // Upload metadata to IPFS
      const metadataHash = projectData.isPrivate
        ? await ipfsService.encryptAndUpload(metadata, "project-password")
        : await ipfsService.uploadJSON(metadata)

      // Encode project data
      const encodedProjectData = new TextEncoder().encode(
        JSON.stringify({
          ...projectData,
          fileHashes,
          metadataHash,
        }),
      )

      const contractAddress = CONTRACT_ADDRESSES[chainId as keyof typeof CONTRACT_ADDRESSES]?.nftContract
      if (!contractAddress) {
        throw new Error(`Contract not deployed on chain ${chainId}`)
      }

      // Mint NFT
      writeContract({
        address: contractAddress as `0x${string}`,
        abi: NFT_CONTRACT_ABI,
        functionName: "mintProject",
        args: [
          "0x...", // recipient address (should be current user)
          metadataHash,
          encodedProjectData,
        ],
        value: parseEther("0.01"), // Minting fee
      })
    } catch (error) {
      console.error("Error minting project:", error)
      throw error
    }
  }

  return {
    mintProject,
    hash,
    isPending: isPending || isConfirming,
    isSuccess,
    error,
  }
}

// Hook for reading user's NFTs
export function useUserNFTs(address: string | undefined, chainId: number) {
  const contractAddress = CONTRACT_ADDRESSES[chainId as keyof typeof CONTRACT_ADDRESSES]?.nftContract

  const { data: balance } = useReadContract({
    address: contractAddress as `0x${string}`,
    abi: NFT_CONTRACT_ABI,
    functionName: "balanceOf",
    args: address ? [address as `0x${string}`] : undefined,
    query: {
      enabled: !!address && !!contractAddress,
    },
  })

  return {
    balance: balance ? Number(balance) : 0,
  }
}

// Hook for listing NFT on marketplace
export function useListProject() {
  const { writeContract, data: hash, isPending, error } = useWriteContract()
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({
    hash,
  })

  const listProject = async (tokenId: number, price: string, chainId: number) => {
    const contractAddress = CONTRACT_ADDRESSES[chainId as keyof typeof CONTRACT_ADDRESSES]?.marketplace
    if (!contractAddress) {
      throw new Error(`Marketplace contract not deployed on chain ${chainId}`)
    }

    writeContract({
      address: contractAddress as `0x${string}`,
      abi: MARKETPLACE_CONTRACT_ABI,
      functionName: "listProject",
      args: [BigInt(tokenId), parseEther(price)],
    })
  }

  return {
    listProject,
    hash,
    isPending: isPending || isConfirming,
    isSuccess,
    error,
  }
}

// Hook for buying NFT from marketplace
export function useBuyProject() {
  const { writeContract, data: hash, isPending, error } = useWriteContract()
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({
    hash,
  })

  const buyProject = async (tokenId: number, price: string, chainId: number) => {
    const contractAddress = CONTRACT_ADDRESSES[chainId as keyof typeof CONTRACT_ADDRESSES]?.marketplace
    if (!contractAddress) {
      throw new Error(`Marketplace contract not deployed on chain ${chainId}`)
    }

    writeContract({
      address: contractAddress as `0x${string}`,
      abi: MARKETPLACE_CONTRACT_ABI,
      functionName: "buyProject",
      args: [BigInt(tokenId)],
      value: parseEther(price),
    })
  }

  return {
    buyProject,
    hash,
    isPending: isPending || isConfirming,
    isSuccess,
    error,
  }
}
