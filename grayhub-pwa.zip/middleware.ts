import { type NextRequest, NextResponse } from "next/server"
import { validateSession } from "@/lib/auth"
import { SecurityService } from "@/lib/security"

export async function middleware(request: NextRequest) {
  // Add security headers to all responses
  const response = NextResponse.next()
  const securityHeaders = SecurityService.getSecurityHeaders()

  Object.entries(securityHeaders).forEach(([key, value]) => {
    response.headers.set(key, value)
  })

  // Protected routes
  const protectedPaths = ["/dashboard", "/profile", "/settings", "/collaborate"]
  const isProtectedPath = protectedPaths.some((path) => request.nextUrl.pathname.startsWith(path))

  if (isProtectedPath) {
    const sessionToken = request.cookies.get("session-token")?.value

    if (!sessionToken) {
      return NextResponse.redirect(new URL("/auth/connect", request.url))
    }

    const session = await validateSession(sessionToken)
    if (!session) {
      const response = NextResponse.redirect(new URL("/auth/connect", request.url))
      response.cookies.delete("session-token")
      return response
    }

    // Check for account lockout
    const lockoutStatus = await SecurityService.checkAccountLockout(session.userId)
    if (lockoutStatus.locked) {
      const response = NextResponse.redirect(new URL("/auth/locked", request.url))
      return response
    }

    // Add user info to headers for server components
    response.headers.set("x-user-id", session.userId)
    return response
  }

  return response
}

export const config = {
  matcher: ["/dashboard/:path*", "/profile/:path*", "/settings/:path*", "/collaborate/:path*"],
}
