import { create } from "zustand"
import { persist } from "zustand/middleware"

interface Verification {
  id: string
  fileName: string
  fileType: string
  result: "AUTHENTIC" | "FAKE" | "SUSPICIOUS"
  confidence: number
  timestamp: Date
  details: {
    signatures: { verified: boolean; count: number }
    logos: { verified: boolean; count: number }
    seals: { verified: boolean; count: number }
    qrCodes: { verified: boolean; count: number }
    blockchainHash?: string
    issuer?: string
    issueDate?: string
    expiryDate?: string
  }
}

interface VerificationStore {
  verifications: Verification[]
  addVerification: (verification: Verification) => void
  removeVerification: (id: string) => void
  clearHistory: () => void
  getVerificationById: (id: string) => Verification | undefined
}

export const useVerificationStore = create<VerificationStore>()(
  persist(
    (set, get) => ({
      verifications: [],

      addVerification: (verification) =>
        set((state) => ({
          verifications: [verification, ...state.verifications],
        })),

      removeVerification: (id) =>
        set((state) => ({
          verifications: state.verifications.filter((v) => v.id !== id),
        })),

      clearHistory: () => set({ verifications: [] }),

      getVerificationById: (id) => get().verifications.find((v) => v.id === id),
    }),
    {
      name: "verification-history",
    },
  ),
)
