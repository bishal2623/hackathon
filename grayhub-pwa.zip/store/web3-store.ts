import { create } from "zustand"
import { persist } from "zustand/middleware"

interface Web3State {
  // Connection state
  isConnected: boolean
  address: string | null
  chainId: number | null

  // User preferences
  preferredChain: number

  // Transaction history
  transactions: Array<{
    hash: string
    type: "mint" | "list" | "buy" | "transfer"
    timestamp: number
    status: "pending" | "confirmed" | "failed"
    projectId?: string
  }>

  // Actions
  setConnection: (isConnected: boolean, address: string | null, chainId: number | null) => void
  setPreferredChain: (chainId: number) => void
  addTransaction: (transaction: Omit<Web3State["transactions"][0], "timestamp">) => void
  updateTransactionStatus: (hash: string, status: "confirmed" | "failed") => void
}

export const useWeb3Store = create<Web3State>()(
  persist(
    (set, get) => ({
      isConnected: false,
      address: null,
      chainId: null,
      preferredChain: 1, // Ethereum mainnet
      transactions: [],

      setConnection: (isConnected, address, chainId) => set({ isConnected, address, chainId }),

      setPreferredChain: (chainId) => set({ preferredChain: chainId }),

      addTransaction: (transaction) =>
        set((state) => ({
          transactions: [{ ...transaction, timestamp: Date.now() }, ...state.transactions].slice(0, 100), // Keep only last 100 transactions
        })),

      updateTransactionStatus: (hash, status) =>
        set((state) => ({
          transactions: state.transactions.map((tx) => (tx.hash === hash ? { ...tx, status } : tx)),
        })),
    }),
    {
      name: "grayhub-web3-storage",
      partialize: (state) => ({
        preferredChain: state.preferredChain,
        transactions: state.transactions,
      }),
    },
  ),
)
