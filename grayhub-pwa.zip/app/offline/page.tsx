"use client"

import { Wifi, RefreshCw } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function OfflinePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-white to-violet-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full text-center space-y-6">
        <div className="w-24 h-24 mx-auto bg-violet-100 rounded-full flex items-center justify-center">
          <Wifi className="w-12 h-12 text-violet-600" />
        </div>

        <div className="space-y-2">
          <h1 className="text-2xl font-bold text-gray-900">You're Offline</h1>
          <p className="text-gray-600">No internet connection detected. Some features may be limited.</p>
        </div>

        <div className="space-y-4">
          <p className="text-sm text-gray-500">
            You can still browse your recently viewed projects and access cached content.
          </p>

          <Button onClick={() => window.location.reload()} className="w-full bg-black text-white hover:bg-gray-800">
            <RefreshCw className="w-4 h-4 mr-2" />
            Try Again
          </Button>
        </div>
      </div>
    </div>
  )
}
