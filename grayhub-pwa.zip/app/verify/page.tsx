"use client"

import type React from "react"

import { useState, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Upload, Camera, FileText, Shield, History, Scan, CheckCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/hooks/use-toast"
import { VerificationResult } from "@/components/verification-result"
import { VerificationHistory } from "@/components/verification-history"
import { useVerificationStore } from "@/store/verification-store"

export default function VerifyPage() {
  const [isVerifying, setIsVerifying] = useState(false)
  const [dragActive, setDragActive] = useState(false)
  const [currentResult, setCurrentResult] = useState<any>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const cameraInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()
  const { addVerification, verifications } = useVerificationStore()

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0])
    }
  }

  const handleFileUpload = async (file: File) => {
    if (!file) return

    // Validate file type
    const validTypes = ["application/pdf", "image/jpeg", "image/png", "image/webp"]
    if (!validTypes.includes(file.type)) {
      toast({
        title: "Invalid file type",
        description: "Please upload a PDF or image file (JPEG, PNG, WebP)",
        variant: "destructive",
      })
      return
    }

    // Validate file size (10MB max)
    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please upload a file smaller than 10MB",
        variant: "destructive",
      })
      return
    }

    setIsVerifying(true)

    try {
      const formData = new FormData()
      formData.append("file", file)
      formData.append("type", file.type.includes("pdf") ? "patent" : "certificate")

      const response = await fetch("/api/verify/document", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        throw new Error("Verification failed")
      }

      const result = await response.json()
      setCurrentResult(result)

      // Add to verification history
      addVerification({
        id: Date.now().toString(),
        fileName: file.name,
        fileType: file.type,
        result: result.status,
        confidence: result.confidence,
        timestamp: new Date(),
        details: result.details,
      })

      // Show push notification if supported
      if ("serviceWorker" in navigator && "Notification" in window) {
        if (Notification.permission === "granted") {
          navigator.serviceWorker.ready.then((registration) => {
            registration.showNotification("Verification Complete", {
              body: `${file.name} - ${result.status} (${result.confidence}% confidence)`,
              icon: "/icons/icon-192x192.jpg",
              badge: "/icons/icon-192x192.jpg",
              tag: "verification-result",
            })
          })
        }
      }

      toast({
        title: "Verification complete",
        description: `Document verified with ${result.confidence}% confidence`,
      })
    } catch (error) {
      console.error("Verification error:", error)
      toast({
        title: "Verification failed",
        description: "Please try again or check your connection",
        variant: "destructive",
      })
    } finally {
      setIsVerifying(false)
    }
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileUpload(e.target.files[0])
    }
  }

  const openCamera = () => {
    if (cameraInputRef.current) {
      cameraInputRef.current.click()
    }
  }

  const openFileDialog = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click()
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-violet-50 p-4">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <div className="p-3 bg-gradient-to-r from-violet-500 to-blue-500 rounded-xl">
              <Shield className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-violet-600 to-blue-600 bg-clip-text text-transparent">
              Patent & Certificate Verifier
            </h1>
          </div>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Upload or scan patents and certificates to verify their authenticity using AI-powered analysis
          </p>
        </motion.div>

        <Tabs defaultValue="verify" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto">
            <TabsTrigger value="verify" className="flex items-center gap-2">
              <Scan className="h-4 w-4" />
              Verify Document
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center gap-2">
              <History className="h-4 w-4" />
              History
            </TabsTrigger>
          </TabsList>

          <TabsContent value="verify" className="space-y-6">
            {/* Upload Area */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
              <Card className="border-2 border-dashed border-slate-300 hover:border-violet-400 transition-colors">
                <CardContent className="p-8">
                  <div
                    className={`relative rounded-xl border-2 border-dashed transition-all duration-300 ${
                      dragActive
                        ? "border-violet-500 bg-violet-50"
                        : "border-slate-300 hover:border-violet-400 hover:bg-slate-50"
                    }`}
                    onDragEnter={handleDrag}
                    onDragLeave={handleDrag}
                    onDragOver={handleDrag}
                    onDrop={handleDrop}
                  >
                    <div className="p-12 text-center space-y-6">
                      <div className="flex justify-center">
                        <div className="p-4 bg-gradient-to-r from-violet-100 to-blue-100 rounded-full">
                          <Upload className="h-12 w-12 text-violet-600" />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <h3 className="text-xl font-semibold text-slate-800">Upload Document for Verification</h3>
                        <p className="text-slate-600">Drag and drop your patent or certificate, or click to browse</p>
                        <p className="text-sm text-slate-500">Supports PDF, JPEG, PNG, WebP (max 10MB)</p>
                      </div>

                      <div className="flex flex-col sm:flex-row gap-4 justify-center">
                        <Button
                          onClick={openFileDialog}
                          disabled={isVerifying}
                          className="bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-700 hover:to-blue-700"
                        >
                          <FileText className="h-4 w-4 mr-2" />
                          Choose File
                        </Button>

                        <Button
                          onClick={openCamera}
                          disabled={isVerifying}
                          variant="outline"
                          className="border-violet-300 text-violet-700 hover:bg-violet-50 bg-transparent"
                        >
                          <Camera className="h-4 w-4 mr-2" />
                          Take Photo
                        </Button>
                      </div>

                      {isVerifying && (
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                          <div className="flex items-center justify-center gap-2">
                            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-violet-600"></div>
                            <span className="text-violet-600 font-medium">Verifying document...</span>
                          </div>
                          <Progress value={75} className="w-full max-w-md mx-auto" />
                        </motion.div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Verification Result */}
            <AnimatePresence>
              {currentResult && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                >
                  <VerificationResult result={currentResult} />
                </motion.div>
              )}
            </AnimatePresence>

            {/* Features Grid */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="grid md:grid-cols-3 gap-6"
            >
              <Card className="bg-white/70 backdrop-blur-sm border-violet-200">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-violet-700">
                    <Shield className="h-5 w-5" />
                    AI Verification
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600">
                    Advanced AI analyzes signatures, logos, seals, and QR codes for authenticity
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-white/70 backdrop-blur-sm border-blue-200">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-blue-700">
                    <CheckCircle className="h-5 w-5" />
                    Blockchain Verification
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600">
                    Optional blockchain hash verification for NFT patents and certificates
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-white/70 backdrop-blur-sm border-emerald-200">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-emerald-700">
                    <History className="h-5 w-5" />
                    Offline Support
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600">
                    Works offline with background sync and push notifications for results
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          <TabsContent value="history">
            <VerificationHistory verifications={verifications} />
          </TabsContent>
        </Tabs>

        {/* Hidden file inputs */}
        <input
          ref={fileInputRef}
          type="file"
          accept=".pdf,.jpg,.jpeg,.png,.webp"
          onChange={handleFileSelect}
          className="hidden"
        />
        <input
          ref={cameraInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          onChange={handleFileSelect}
          className="hidden"
        />
      </div>
    </div>
  )
}
