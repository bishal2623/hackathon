"use client"

import { useState } from "react"
import { Navbar } from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ProjectCard } from "@/components/project-card"
import { AnalyticsChart } from "@/components/analytics-chart"
import { PatentScoreMeter } from "@/components/patent-score-meter"
import { TrendingUp, Eye, Heart, DollarSign, Users, Award, Zap, Plus, Filter, BarChart3 } from "lucide-react"
import Link from "next/link"

// Mock user data - in real app, this would come from API/blockchain
const mockUserData = {
  address: "0x1234...5678",
  name: "Sarah Chen",
  grayScore: 87,
  totalProjects: 12,
  totalViews: 15420,
  totalLikes: 892,
  totalEarnings: "4.2",
  collaborations: 8,
  patentScore: 89,
  rank: 42,
  joinedDate: "2024-01-15",
}

const mockUserProjects = [
  {
    id: "1",
    title: "AI-Powered Smart Garden System",
    description:
      "An IoT-based automated garden management system using machine learning to optimize plant growth conditions.",
    author: "Sarah Chen",
    patentScore: 87,
    category: "IoT & Agriculture",
    likes: 124,
    views: 1250,
    price: "0.5",
    blockchain: "ethereum" as const,
    status: "minted",
    earnings: "1.2",
  },
  {
    id: "2",
    title: "Blockchain Voting Platform",
    description: "A secure, transparent voting system built on blockchain technology.",
    author: "Sarah Chen",
    patentScore: 92,
    category: "Blockchain & Security",
    likes: 89,
    views: 890,
    price: "0.8",
    blockchain: "polygon" as const,
    status: "pending",
    earnings: "0.0",
  },
  {
    id: "3",
    title: "Neural Music Composer",
    description: "An AI system that composes original music by learning from classical pieces.",
    author: "Sarah Chen",
    patentScore: 76,
    category: "AI & Music",
    likes: 156,
    views: 2100,
    price: "0.3",
    blockchain: "base" as const,
    status: "minted",
    earnings: "2.1",
  },
]

const mockAnalyticsData = {
  viewsOverTime: [
    { month: "Jan", views: 1200, likes: 45 },
    { month: "Feb", views: 1800, likes: 67 },
    { month: "Mar", views: 2400, likes: 89 },
    { month: "Apr", views: 3200, likes: 124 },
    { month: "May", views: 2800, likes: 98 },
    { month: "Jun", views: 4100, likes: 156 },
  ],
  earningsOverTime: [
    { month: "Jan", earnings: 0.5 },
    { month: "Feb", earnings: 1.2 },
    { month: "Mar", earnings: 1.8 },
    { month: "Apr", earnings: 2.5 },
    { month: "May", earnings: 3.1 },
    { month: "Jun", earnings: 4.2 },
  ],
}

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="min-h-screen grayhub-gradient">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">Dashboard</h1>
            <p className="text-xl text-gray-600">Welcome back, {mockUserData.name}</p>
          </div>
          <div className="flex items-center gap-4 mt-4 md:mt-0">
            <Button asChild className="bg-black text-white hover:bg-gray-800">
              <Link href="/projects/submit">
                <Plus className="w-4 h-4 mr-2" />
                New Project
              </Link>
            </Button>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-8">
          <Card className="grayhub-card-glow">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">GrayScore</p>
                  <p className="text-2xl font-bold text-[#6C63FF]">{mockUserData.grayScore}</p>
                </div>
                <Award className="w-8 h-8 text-[#6C63FF]" />
              </div>
            </CardContent>
          </Card>

          <Card className="grayhub-card-glow">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Projects</p>
                  <p className="text-2xl font-bold text-gray-900">{mockUserData.totalProjects}</p>
                </div>
                <Zap className="w-8 h-8 text-gray-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="grayhub-card-glow">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Views</p>
                  <p className="text-2xl font-bold text-gray-900">{mockUserData.totalViews.toLocaleString()}</p>
                </div>
                <Eye className="w-8 h-8 text-gray-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="grayhub-card-glow">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Likes</p>
                  <p className="text-2xl font-bold text-gray-900">{mockUserData.totalLikes}</p>
                </div>
                <Heart className="w-8 h-8 text-gray-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="grayhub-card-glow">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Earnings</p>
                  <p className="text-2xl font-bold text-green-600">{mockUserData.totalEarnings} ETH</p>
                </div>
                <DollarSign className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="grayhub-card-glow">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Rank</p>
                  <p className="text-2xl font-bold text-orange-600">#{mockUserData.rank}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="projects">My Projects</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="collaborations">Collaborations</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid lg:grid-cols-3 gap-6">
              {/* Patent Score & Performance */}
              <Card className="grayhub-card-glow">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Award className="w-5 h-5 mr-2 text-[#6C63FF]" />
                    Patent Performance
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <PatentScoreMeter score={mockUserData.patentScore} size="lg" />
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Average Score:</span>
                      <span className="font-medium">{mockUserData.patentScore}/100</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Global Rank:</span>
                      <span className="font-medium">#{mockUserData.rank}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Improvement:</span>
                      <span className="font-medium text-green-600">+5 this month</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Recent Activity */}
              <Card className="lg:col-span-2 grayhub-card-glow">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BarChart3 className="w-5 h-5 mr-2 text-[#6C63FF]" />
                    Recent Activity
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center">
                        <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                        <div>
                          <p className="font-medium text-gray-900">Project "AI Garden System" sold</p>
                          <p className="text-sm text-gray-600">2 hours ago</p>
                        </div>
                      </div>
                      <Badge className="bg-green-100 text-green-800">+0.5 ETH</Badge>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center">
                        <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
                        <div>
                          <p className="font-medium text-gray-900">New collaboration request</p>
                          <p className="text-sm text-gray-600">1 day ago</p>
                        </div>
                      </div>
                      <Badge variant="outline">Pending</Badge>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center">
                        <div className="w-2 h-2 bg-purple-500 rounded-full mr-3"></div>
                        <div>
                          <p className="font-medium text-gray-900">Patent score improved</p>
                          <p className="text-sm text-gray-600">3 days ago</p>
                        </div>
                      </div>
                      <Badge className="bg-purple-100 text-purple-800">+5 points</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Projects Tab */}
          <TabsContent value="projects" className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-semibold text-gray-900">My Projects ({mockUserProjects.length})</h3>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm">
                  <Filter className="w-4 h-4 mr-2" />
                  Filter
                </Button>
              </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {mockUserProjects.map((project) => (
                <div key={project.id} className="relative">
                  <ProjectCard {...project} />
                  <div className="absolute top-3 right-3">
                    <Badge
                      className={
                        project.status === "minted" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"
                      }
                    >
                      {project.status === "minted" ? "Live" : "Pending"}
                    </Badge>
                  </div>
                  {project.status === "minted" && (
                    <div className="mt-2 text-center">
                      <p className="text-sm text-gray-600">
                        Earned: <span className="font-medium text-green-600">{project.earnings} ETH</span>
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card className="grayhub-card-glow">
                <CardHeader>
                  <CardTitle>Views & Engagement</CardTitle>
                </CardHeader>
                <CardContent>
                  <AnalyticsChart data={mockAnalyticsData.viewsOverTime} type="engagement" />
                </CardContent>
              </Card>

              <Card className="grayhub-card-glow">
                <CardHeader>
                  <CardTitle>Earnings Over Time</CardTitle>
                </CardHeader>
                <CardContent>
                  <AnalyticsChart data={mockAnalyticsData.earningsOverTime} type="earnings" />
                </CardContent>
              </Card>
            </div>

            {/* Detailed Analytics */}
            <Card className="grayhub-card-glow">
              <CardHeader>
                <CardTitle>Project Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockUserProjects.map((project) => (
                    <div
                      key={project.id}
                      className="flex items-center justify-between p-4 border border-gray-200 rounded-lg"
                    >
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900">{project.title}</h4>
                        <div className="flex items-center gap-4 mt-2 text-sm text-gray-600">
                          <span className="flex items-center">
                            <Eye className="w-4 h-4 mr-1" />
                            {project.views} views
                          </span>
                          <span className="flex items-center">
                            <Heart className="w-4 h-4 mr-1" />
                            {project.likes} likes
                          </span>
                          <span className="flex items-center">
                            <DollarSign className="w-4 h-4 mr-1" />
                            {project.earnings} ETH
                          </span>
                        </div>
                      </div>
                      <div className="text-right">
                        <PatentScoreMeter score={project.patentScore} size="sm" />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Collaborations Tab */}
          <TabsContent value="collaborations" className="space-y-6">
            <div className="text-center py-12">
              <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Collaboration Hub</h3>
              <p className="text-gray-600 mb-6">Connect with other innovators and work together on projects</p>
              <Button className="bg-[#6C63FF] text-white hover:bg-[#1E2A78]">Find Collaborators</Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
