"use client"

import { useState } from "react"
import { Navbar } from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ProjectCard } from "@/components/project-card"
import {
  Heart,
  MessageCircle,
  Share2,
  User,
  Calendar,
  TrendingUp,
  Filter,
  Search,
  Zap,
  Award,
  Users,
  Bookmark,
} from "lucide-react"

// Mock feed data
const mockFeedItems = [
  {
    id: "1",
    type: "project_published",
    user: {
      name: "Sarah Chen",
      address: "0x1234...5678",
      avatar: "",
      grayScore: 87,
    },
    timestamp: "2 hours ago",
    content: {
      title: "AI-Powered Smart Garden System",
      description:
        "Just published my latest IoT project that uses machine learning to optimize plant growth conditions!",
      image: "",
      patentScore: 87,
      category: "IoT & Agriculture",
      likes: 24,
      comments: 8,
      shares: 3,
    },
    project: {
      id: "1",
      title: "AI-Powered Smart Garden System",
      description:
        "An IoT-based automated garden management system using machine learning to optimize plant growth conditions.",
      author: "Sarah Chen",
      patentScore: 87,
      category: "IoT & Agriculture",
      likes: 124,
      views: 1250,
      price: "0.5",
      blockchain: "ethereum" as const,
    },
  },
  {
    id: "2",
    type: "collaboration_started",
    user: {
      name: "Alex Rodriguez",
      address: "0x5678...9012",
      avatar: "",
      grayScore: 92,
    },
    timestamp: "4 hours ago",
    content: {
      title: "Started collaboration on Blockchain Voting Platform",
      description: "Excited to work with @maya_patel on implementing zero-knowledge proofs for our voting system!",
      collaborator: "Maya Patel",
      likes: 15,
      comments: 4,
      shares: 2,
    },
  },
  {
    id: "3",
    type: "achievement_earned",
    user: {
      name: "Maya Patel",
      address: "0x9012...3456",
      avatar: "",
      grayScore: 76,
    },
    timestamp: "6 hours ago",
    content: {
      title: "Earned 'AI Pioneer' Badge",
      description:
        "Just earned the AI Pioneer badge for publishing 5+ AI-related projects! Thanks to the community for the support.",
      badge: {
        name: "AI Pioneer",
        icon: "🤖",
        description: "Published 5+ AI projects",
      },
      likes: 42,
      comments: 12,
      shares: 8,
    },
  },
  {
    id: "4",
    type: "patent_score_improved",
    user: {
      name: "David Kim",
      address: "0x3456...7890",
      avatar: "",
      grayScore: 84,
    },
    timestamp: "8 hours ago",
    content: {
      title: "Patent Score Improved",
      description:
        "My Sustainable Energy Management App just got a patent score boost to 84! The AI suggestions really helped.",
      oldScore: 79,
      newScore: 84,
      improvement: 5,
      likes: 18,
      comments: 6,
      shares: 1,
    },
  },
  {
    id: "5",
    type: "project_sold",
    user: {
      name: "Emma Johnson",
      address: "0x7890...1234",
      avatar: "",
      grayScore: 79,
    },
    timestamp: "12 hours ago",
    content: {
      title: "AR Learning Platform NFT Sold!",
      description: "Thrilled to announce that my AR-Based Learning Platform NFT just sold for 0.6 ETH! 🎉",
      salePrice: "0.6",
      blockchain: "arbitrum",
      likes: 67,
      comments: 23,
      shares: 15,
    },
  },
]

const mockTrendingProjects = [
  {
    id: "trending-1",
    title: "Quantum Computing Simulator",
    author: "James Wilson",
    patentScore: 95,
    category: "Quantum Computing",
    likes: 203,
    views: 3200,
    price: "1.2",
    blockchain: "ethereum" as const,
    trend: "+45% this week",
  },
  {
    id: "trending-2",
    title: "Neural Network Music Composer",
    author: "Maya Patel",
    patentScore: 76,
    category: "AI & Music",
    likes: 156,
    views: 2100,
    price: "0.3",
    blockchain: "base" as const,
    trend: "+32% this week",
  },
]

export default function FeedPage() {
  const [activeTab, setActiveTab] = useState("following")
  const [searchQuery, setSearchQuery] = useState("")

  const handleLike = (itemId: string) => {
    // Handle like functionality
    console.log("Liked item:", itemId)
  }

  const handleComment = (itemId: string) => {
    // Handle comment functionality
    console.log("Comment on item:", itemId)
  }

  const handleShare = (itemId: string) => {
    // Handle share functionality
    console.log("Share item:", itemId)
  }

  const renderFeedItem = (item: any) => {
    return (
      <Card key={item.id} className="grayhub-card-glow">
        <CardContent className="p-6">
          {/* User Header */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-gradient-to-br from-[#6C63FF] to-[#1E2A78] rounded-full flex items-center justify-center mr-3">
                <User className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="font-medium text-gray-900">{item.user.name}</h4>
                  <Badge className="bg-[#6C63FF]/10 text-[#6C63FF] text-xs">{item.user.grayScore}</Badge>
                </div>
                <p className="text-sm text-gray-500 font-mono">{item.user.address}</p>
              </div>
            </div>
            <div className="flex items-center text-sm text-gray-500">
              <Calendar className="w-4 h-4 mr-1" />
              {item.timestamp}
            </div>
          </div>

          {/* Content based on type */}
          {item.type === "project_published" && (
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">{item.content.title}</h3>
                <p className="text-gray-700">{item.content.description}</p>
              </div>

              {/* Embedded Project Card */}
              <div className="border border-gray-200 rounded-lg p-4 bg-gray-50">
                <ProjectCard {...item.project} />
              </div>
            </div>
          )}

          {item.type === "collaboration_started" && (
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">{item.content.title}</h3>
                <p className="text-gray-700">{item.content.description}</p>
              </div>
              <div className="flex items-center p-3 bg-blue-50 rounded-lg">
                <Users className="w-5 h-5 text-blue-600 mr-2" />
                <span className="text-blue-800 font-medium">Collaborating with {item.content.collaborator}</span>
              </div>
            </div>
          )}

          {item.type === "achievement_earned" && (
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">{item.content.title}</h3>
                <p className="text-gray-700">{item.content.description}</p>
              </div>
              <div className="flex items-center p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg border border-purple-200">
                <div className="text-3xl mr-3">{item.content.badge.icon}</div>
                <div>
                  <h4 className="font-medium text-purple-900">{item.content.badge.name}</h4>
                  <p className="text-sm text-purple-700">{item.content.badge.description}</p>
                </div>
              </div>
            </div>
          )}

          {item.type === "patent_score_improved" && (
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">{item.content.title}</h3>
                <p className="text-gray-700">{item.content.description}</p>
              </div>
              <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg border border-green-200">
                <div className="flex items-center">
                  <TrendingUp className="w-5 h-5 text-green-600 mr-2" />
                  <span className="text-green-800 font-medium">
                    Score improved from {item.content.oldScore} to {item.content.newScore}
                  </span>
                </div>
                <Badge className="bg-green-100 text-green-800">+{item.content.improvement} points</Badge>
              </div>
            </div>
          )}

          {item.type === "project_sold" && (
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">{item.content.title}</h3>
                <p className="text-gray-700">{item.content.description}</p>
              </div>
              <div className="flex items-center justify-between p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                <div className="flex items-center">
                  <Zap className="w-5 h-5 text-yellow-600 mr-2" />
                  <span className="text-yellow-800 font-medium">Sold for {item.content.salePrice} ETH</span>
                </div>
                <Badge className="bg-yellow-100 text-yellow-800 capitalize">{item.content.blockchain}</Badge>
              </div>
            </div>
          )}

          {/* Engagement Actions */}
          <div className="flex items-center justify-between pt-4 border-t border-gray-200">
            <div className="flex items-center space-x-6">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleLike(item.id)}
                className="text-gray-600 hover:text-red-600"
              >
                <Heart className="w-4 h-4 mr-1" />
                {item.content.likes}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleComment(item.id)}
                className="text-gray-600 hover:text-blue-600"
              >
                <MessageCircle className="w-4 h-4 mr-1" />
                {item.content.comments}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleShare(item.id)}
                className="text-gray-600 hover:text-green-600"
              >
                <Share2 className="w-4 h-4 mr-1" />
                {item.content.shares}
              </Button>
            </div>
            <Button variant="ghost" size="sm" className="text-gray-600 hover:text-[#6C63FF]">
              <Bookmark className="w-4 h-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="min-h-screen grayhub-gradient">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Main Feed */}
          <div className="lg:col-span-3 space-y-6">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div>
                <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">Project Feed</h1>
                <p className="text-xl text-gray-600">Stay updated with the latest innovations</p>
              </div>
              <div className="flex items-center gap-4 mt-4 md:mt-0">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search feed..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 w-64"
                  />
                </div>
                <Button variant="outline">
                  <Filter className="w-4 h-4 mr-2" />
                  Filter
                </Button>
              </div>
            </div>

            {/* Feed Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="following">Following</TabsTrigger>
                <TabsTrigger value="trending">Trending</TabsTrigger>
                <TabsTrigger value="recent">Recent</TabsTrigger>
              </TabsList>

              <TabsContent value="following" className="space-y-6 mt-6">
                {mockFeedItems.map(renderFeedItem)}
              </TabsContent>

              <TabsContent value="trending" className="space-y-6 mt-6">
                <div className="text-center py-8">
                  <TrendingUp className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Trending Projects</h3>
                  <p className="text-gray-600 mb-6">Discover the most popular projects this week</p>
                  <div className="grid md:grid-cols-2 gap-6">
                    {mockTrendingProjects.map((project) => (
                      <div key={project.id} className="relative">
                        <ProjectCard {...project} />
                        <Badge className="absolute top-3 left-3 bg-orange-100 text-orange-800">{project.trend}</Badge>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="recent" className="space-y-6 mt-6">
                {mockFeedItems.slice().reverse().map(renderFeedItem)}
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Trending Topics */}
            <Card className="grayhub-card-glow">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="w-5 h-5 mr-2 text-[#6C63FF]" />
                  Trending Topics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-900 font-medium">#AI</span>
                    <Badge variant="outline">142 posts</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-900 font-medium">#Blockchain</span>
                    <Badge variant="outline">89 posts</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-900 font-medium">#IoT</span>
                    <Badge variant="outline">67 posts</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-900 font-medium">#Sustainability</span>
                    <Badge variant="outline">54 posts</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-900 font-medium">#DeFi</span>
                    <Badge variant="outline">43 posts</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Top Contributors */}
            <Card className="grayhub-card-glow">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Award className="w-5 h-5 mr-2 text-[#6C63FF]" />
                  Top Contributors
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-8 h-8 bg-gradient-to-br from-[#6C63FF] to-[#1E2A78] rounded-full flex items-center justify-center mr-3">
                        <User className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900 text-sm">Sarah Chen</p>
                        <p className="text-xs text-gray-500">12 projects</p>
                      </div>
                    </div>
                    <Badge className="bg-[#6C63FF]/10 text-[#6C63FF]">87</Badge>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-8 h-8 bg-gradient-to-br from-[#6C63FF] to-[#1E2A78] rounded-full flex items-center justify-center mr-3">
                        <User className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900 text-sm">Alex Rodriguez</p>
                        <p className="text-xs text-gray-500">8 projects</p>
                      </div>
                    </div>
                    <Badge className="bg-[#6C63FF]/10 text-[#6C63FF]">92</Badge>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-8 h-8 bg-gradient-to-br from-[#6C63FF] to-[#1E2A78] rounded-full flex items-center justify-center mr-3">
                        <User className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900 text-sm">Maya Patel</p>
                        <p className="text-xs text-gray-500">6 projects</p>
                      </div>
                    </div>
                    <Badge className="bg-[#6C63FF]/10 text-[#6C63FF]">76</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Suggested Follows */}
            <Card className="grayhub-card-glow">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="w-5 h-5 mr-2 text-[#6C63FF]" />
                  Suggested Follows
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-8 h-8 bg-gradient-to-br from-[#6C63FF] to-[#1E2A78] rounded-full flex items-center justify-center mr-3">
                        <User className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900 text-sm">David Kim</p>
                        <p className="text-xs text-gray-500">Sustainability Expert</p>
                      </div>
                    </div>
                    <Button size="sm" className="bg-[#6C63FF] text-white hover:bg-[#1E2A78]">
                      Follow
                    </Button>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-8 h-8 bg-gradient-to-br from-[#6C63FF] to-[#1E2A78] rounded-full flex items-center justify-center mr-3">
                        <User className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900 text-sm">Emma Johnson</p>
                        <p className="text-xs text-gray-500">AR/VR Developer</p>
                      </div>
                    </div>
                    <Button size="sm" className="bg-[#6C63FF] text-white hover:bg-[#1E2A78]">
                      Follow
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
