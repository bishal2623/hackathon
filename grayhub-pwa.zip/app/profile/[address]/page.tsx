"us```tsx file=\"app/profile/[address]/page.tsx"
"use client"

import { useState } from "react"
import { useParams } from "next/navigation"
import { Navbar } from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ProjectCard } from "@/components/project-card"
import { PatentScoreMeter } from "@/components/patent-score-meter"
import {
  User,
  MapPin,
  Calendar,
  Award,
  Users,
  MessageCircle,
  Share2,
  Github,
  Twitter,
  Globe,
  Verified,
} from "lucide-react"

// Mock profile data - in real app, this would come from API/blockchain
const mockProfile = {
  address: "0x1234...5678",
  name: "Sarah Chen",
  bio: "Full-stack developer and AI researcher passionate about sustainable technology and blockchain innovation. Currently pursuing PhD in Computer Science at MIT.",
  avatar: "",
  location: "Boston, MA",
  website: "https://sarahchen.dev",
  twitter: "@sarahchen_dev",
  github: "sarahchen",
  email: "sarah@example.com",
  joinedDate: "2024-01-15",
  isVerified: true,
  grayScore: 87,
  reputation: "Expert",
  totalProjects: 12,
  totalViews: 15420,
  totalLikes: 892,
  totalEarnings: "4.2",
  collaborations: 8,
  followers: 1247,
  following: 342,
  patentScore: 89,
  rank: 42,
  badges: [
    { name: "Early Adopter", icon: "🚀", description: "Joined in the first month" },
    { name: "AI Pioneer", icon: "🤖", description: "Published 5+ AI projects" },
    { name: "Top Collaborator", icon: "🤝", description: "Collaborated on 10+ projects" },
    { name: "Patent Master", icon: "📜", description: "Average patent score >85" },
  ],
  skills: ["Machine Learning", "Blockchain", "IoT", "React", "Python", "Solidity"],
  interests: ["Sustainability", "AI Ethics", "DeFi", "Smart Cities"],
}

const mockUserProjects = [
  {
    id: "1",
    title: "AI-Powered Smart Garden System",
    description:
      "An IoT-based automated garden management system using machine learning to optimize plant growth conditions.",
    author: "Sarah Chen",
    patentScore: 87,
    category: "IoT & Agriculture",
    likes: 124,
    views: 1250,
    price: "0.5",
    blockchain: "ethereum" as const,
  },
  {
    id: "2",
    title: "Blockchain Voting Platform",
    description: "A secure, transparent voting system built on blockchain technology.",
    author: "Sarah Chen",
    patentScore: 92,
    category: "Blockchain & Security",
    likes: 89,
    views: 890,
    price: "0.8",
    blockchain: "polygon" as const,
  },
  {
    id: "3",
    title: "Neural Music Composer",
    description: "An AI system that composes original music by learning from classical pieces.",
    author: "Sarah Chen",
    patentScore: 76,
    category: "AI & Music",
    likes: 156,
    views: 2100,
    price: "0.3",
    blockchain: "base" as const,
  },
]

export default function ProfilePage() {
  const params = useParams()
  const [isFollowing, setIsFollowing] = useState(false)
  const [activeTab, setActiveTab] = useState("projects")

  const handleFollow = () => {
    setIsFollowing(!isFollowing)
  }

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${mockProfile.name} - GrayHub Profile`,
          text: mockProfile.bio,
          url: window.location.href,
        })
      } catch (error) {
        console.log("Error sharing:", error)
      }
    } else {
      navigator.clipboard.writeText(window.location.href)
      alert("Profile link copied to clipboard!")
    }
  }

  return (
    <div className="min-h-screen grayhub-gradient">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Profile Header */}
        <Card className="grayhub-card-glow mb-8">
          <CardContent className="p-8">
            <div className="flex flex-col lg:flex-row gap-8">
              {/* Avatar and Basic Info */}
              <div className="flex flex-col items-center lg:items-start">
                <div className="relative">
                  <div className="w-32 h-32 bg-gradient-to-br from-[#6C63FF] to-[#1E2A78] rounded-full flex items-center justify-center mb-4">
                    <User className="w-16 h-16 text-white" />
                  </div>
                  {mockProfile.isVerified && (
                    <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                      <Verified className="w-5 h-5 text-white" />
                    </div>
                  )}
                </div>

                <div className="text-center lg:text-left">
                  <div className="flex items-center gap-2 mb-2">
                    <h1 className="text-3xl font-bold text-gray-900">{mockProfile.name}</h1>
                    {mockProfile.isVerified && <Verified className="w-6 h-6 text-blue-500" />}
                  </div>
                  <p className="text-gray-600 font-mono text-sm mb-2">{mockProfile.address}</p>
                  <Badge className="bg-[#6C63FF]/10 text-[#6C63FF] mb-4">{mockProfile.reputation}</Badge>
                </div>
              </div>

              {/* Profile Details */}
              <div className="flex-1">
                <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between mb-6">
                  <div className="flex-1">
                    <p className="text-gray-700 text-lg mb-4 leading-relaxed">{mockProfile.bio}</p>

                    <div className="flex flex-wrap gap-4 text-sm text-gray-600 mb-4">
                      {mockProfile.location && (
                        <div className="flex items-center">
                          <MapPin className="w-4 h-4 mr-1" />
                          {mockProfile.location}
                        </div>
                      )}
                      <div className="flex items-center">
                        <Calendar className="w-4 h-4 mr-1" />
                        Joined {new Date(mockProfile.joinedDate).toLocaleDateString()}
                      </div>
                    </div>

                    {/* Social Links */}
                    <div className="flex flex-wrap gap-3 mb-6">
                      {mockProfile.website && (
                        <Button variant="outline" size="sm" asChild>
                          <a href={mockProfile.website} target="_blank" rel="noopener noreferrer">
                            <Globe className="w-4 h-4 mr-2" />
                            Website
                          </a>
                        </Button>
                      )}
                      {mockProfile.github && (
                        <Button variant="outline" size="sm" asChild>
                          <a
                            href={`https://github.com/${mockProfile.github}`}
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <Github className="w-4 h-4 mr-2" />
                            GitHub
                          </a>
                        </Button>
                      )}
                      {mockProfile.twitter && (
                        <Button variant="outline" size="sm" asChild>
                          <a
                            href={`https://twitter.com/${mockProfile.twitter.replace("@", "")}`}
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <Twitter className="w-4 h-4 mr-2" />
                            Twitter
                          </a>
                        </Button>
                      )}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-3">
                    <Button
                      onClick={handleFollow}
                      className={
                        isFollowing
                          ? "bg-gray-200 text-gray-800 hover:bg-gray-300"
                          : "bg-[#6C63FF] text-white hover:bg-[#1E2A78]"
                      }
                    >
                      <Users className="w-4 h-4 mr-2" />
                      {isFollowing ? "Following" : "Follow"}
                    </Button>
                    <Button variant="outline">
                      <MessageCircle className="w-4 h-4 mr-2" />
                      Message
                    </Button>
                    <Button variant="outline" onClick={handleShare}>
                      <Share2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-[#6C63FF]">{mockProfile.grayScore}</div>
                    <div className="text-sm text-gray-600">GrayScore</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900">{mockProfile.totalProjects}</div>
                    <div className="text-sm text-gray-600">Projects</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900">{mockProfile.followers.toLocaleString()}</div>
                    <div className="text-sm text-gray-600">Followers</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900">{mockProfile.following}</div>
                    <div className="text-sm text-gray-600">Following</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">{mockProfile.totalEarnings} ETH</div>
                    <div className="text-sm text-gray-600">Earned</div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Profile Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="projects">Projects</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
            <TabsTrigger value="skills">Skills</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
          </TabsList>

          {/* Projects Tab */}
          <TabsContent value="projects" className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-semibold text-gray-900">Projects ({mockUserProjects.length})</h3>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {mockUserProjects.map((project) => (
                <ProjectCard key={project.id} {...project} />
              ))}
            </div>
          </TabsContent>

          {/* Achievements Tab */}
          <TabsContent value="achievements" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Patent Score */}
              <Card className="grayhub-card-glow">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Award className="w-5 h-5 mr-2 text-[#6C63FF]" />
                    Patent Performance
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <PatentScoreMeter score={mockProfile.patentScore} size="lg" />
                  <div className="mt-4 space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Global Rank:</span>
                      <span className="font-medium">#{mockProfile.rank}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Total Views:</span>
                      <span className="font-medium">{mockProfile.totalViews.toLocaleString()}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Badges */}
              <Card className="grayhub-card-glow">
                <CardHeader>
                  <CardTitle>Badges & Recognition</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    {mockProfile.badges.map((badge, index) => (
                      <div key={index} className="text-center p-4 bg-gray-50 rounded-lg">
                        <div className="text-2xl mb-2">{badge.icon}</div>
                        <h4 className="font-medium text-gray-900 text-sm">{badge.name}</h4>
                        <p className="text-xs text-gray-600 mt-1">{badge.description}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Skills Tab */}
          <TabsContent value="skills" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="grayhub-card-glow">
                <CardHeader>
                  <CardTitle>Technical Skills</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {mockProfile.skills.map((skill) => (
                      <Badge key={skill} variant="outline" className="text-[#6C63FF] border-[#6C63FF]">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="grayhub-card-glow">
                <CardHeader>
                  <CardTitle>Interests</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {mockProfile.interests.map((interest) => (
                      <Badge key={interest} className="bg-gray-100 text-gray-800">
                        {interest}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Activity Tab */}
          <TabsContent value="activity" className="space-y-6">
            <Card className="grayhub-card-glow">
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                      <div>
                        <p className="font-medium text-gray-900">Published "AI Garden System"</p>
                        <p className="text-sm text-gray-600">2 hours ago</p>
                      </div>
                    </div>
                    <Badge className="bg-green-100 text-green-800">New Project</Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
                      <div>
                        <p className="font-medium text-gray-900">Started collaboration with @alexdev</p>
                        <p className="text-sm text-gray-600">1 day ago</p>
                      </div>
                    </div>
                    <Badge variant="outline">Collaboration</Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <div className="w-2 h-2 bg-purple-500 rounded-full mr-3"></div>
                      <div>
                        <p className="font-medium text-gray-900">Earned "AI Pioneer" badge</p>
                        <p className="text-sm text-gray-600">3 days ago</p>
                      </div>
                    </div>
                    <Badge className="bg-purple-100 text-purple-800">Achievement</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
