import { Navbar } from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { ProjectCard } from "@/components/project-card"
import { ArrowRight, Zap, Shield, Brain, Users } from "lucide-react"
import Link from "next/link"

// Mock data for featured projects
const featuredProjects = [
  {
    id: "1",
    title: "AI-Powered Smart Garden System",
    description:
      "An IoT-based automated garden management system using machine learning to optimize plant growth conditions.",
    author: "Sarah Chen",
    patentScore: 87,
    category: "IoT & Agriculture",
    likes: 124,
    views: 1250,
    price: "0.5",
    blockchain: "ethereum" as const,
  },
  {
    id: "2",
    title: "Blockchain-Based Voting Platform",
    description: "A secure, transparent voting system built on blockchain technology with zero-knowledge proofs.",
    author: "Alex Rodriguez",
    patentScore: 92,
    category: "Blockchain & Security",
    isPrivate: true,
    likes: 89,
    views: 890,
    price: "0.8",
    blockchain: "polygon" as const,
  },
  {
    id: "3",
    title: "Neural Network Music Composer",
    description: "An AI system that composes original music by learning from classical and contemporary pieces.",
    author: "Maya Patel",
    patentScore: 76,
    category: "AI & Music",
    likes: 156,
    views: 2100,
    price: "0.3",
    blockchain: "base" as const,
  },
]

export default function HomePage() {
  return (
    <div className="min-h-screen grayhub-gradient">
      <Navbar />

      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <div className="mb-8">
            <div className="inline-flex items-center px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full border border-gray-200 mb-6">
              <Zap className="w-4 h-4 text-[#6C63FF] mr-2" />
              <span className="text-sm font-medium text-gray-700">Transform Student Innovations into NFTs</span>
            </div>

            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6 text-balance">
              The Future of
              <span className="text-transparent bg-gradient-to-r from-[#6C63FF] to-[#1E2A78] bg-clip-text">
                {" "}
                Student Innovation
              </span>
            </h1>

            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto text-pretty">
              GrayHub empowers students to mint their projects as NFTs, get AI-powered patent scoring, and connect with
              mentors in a secure, blockchain-powered ecosystem.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button asChild size="lg" className="bg-black text-white hover:bg-gray-800 px-8 py-3">
              <Link href="/projects/submit">
                Submit Your Project
                <ArrowRight className="w-5 h-5 ml-2" />
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="border-[#6C63FF] text-[#6C63FF] hover:bg-[#6C63FF] hover:text-white px-8 py-3 bg-transparent"
            >
              <Link href="/projects">Explore Marketplace</Link>
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-2xl mx-auto">
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">1,247</div>
              <div className="text-sm text-gray-600">Projects Minted</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">89%</div>
              <div className="text-sm text-gray-600">Avg Patent Score</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">5.2K</div>
              <div className="text-sm text-gray-600">Active Students</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">$2.1M</div>
              <div className="text-sm text-gray-600">Total Volume</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Why Choose GrayHub?</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Everything you need to protect, showcase, and monetize your innovations
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center p-6 bg-white rounded-xl grayhub-card-glow">
              <div className="w-12 h-12 bg-gradient-to-br from-[#6C63FF] to-[#1E2A78] rounded-lg flex items-center justify-center mx-auto mb-4">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Secure & Private</h3>
              <p className="text-gray-600 text-sm">NDA-protected projects with blockchain-verified ownership</p>
            </div>

            <div className="text-center p-6 bg-white rounded-xl grayhub-card-glow">
              <div className="w-12 h-12 bg-gradient-to-br from-[#6C63FF] to-[#1E2A78] rounded-lg flex items-center justify-center mx-auto mb-4">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">AI-Powered Insights</h3>
              <p className="text-gray-600 text-sm">
                Get patent scoring, plagiarism checks, and improvement suggestions
              </p>
            </div>

            <div className="text-center p-6 bg-white rounded-xl grayhub-card-glow">
              <div className="w-12 h-12 bg-gradient-to-br from-[#6C63FF] to-[#1E2A78] rounded-lg flex items-center justify-center mx-auto mb-4">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Multi-Chain Support</h3>
              <p className="text-gray-600 text-sm">Mint on Ethereum, Polygon, Optimism, Arbitrum, and Base</p>
            </div>

            <div className="text-center p-6 bg-white rounded-xl grayhub-card-glow">
              <div className="w-12 h-12 bg-gradient-to-br from-[#6C63FF] to-[#1E2A78] rounded-lg flex items-center justify-center mx-auto mb-4">
                <Users className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Team Collaboration</h3>
              <p className="text-gray-600 text-sm">Shared ownership and collaborative project development</p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Projects */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Featured Projects</h2>
              <p className="text-xl text-gray-600">Discover the latest student innovations</p>
            </div>
            <Button
              asChild
              variant="outline"
              className="border-[#6C63FF] text-[#6C63FF] hover:bg-[#6C63FF] hover:text-white bg-transparent"
            >
              <Link href="/projects">
                View All
                <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredProjects.map((project) => (
              <ProjectCard key={project.id} {...project} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-[#6C63FF] to-[#1E2A78]">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Ready to Transform Your Innovation?</h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Join thousands of students who are already protecting and monetizing their ideas on GrayHub.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-white text-[#6C63FF] hover:bg-gray-100 px-8 py-3">
              <Link href="/projects/submit">
                Get Started Now
                <ArrowRight className="w-5 h-5 ml-2" />
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="border-white text-white hover:bg-white hover:text-[#6C63FF] px-8 py-3 bg-transparent"
            >
              <Link href="/dashboard">View Dashboard</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
