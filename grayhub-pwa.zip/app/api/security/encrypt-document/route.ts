import { type NextRequest, NextResponse } from "next/server"
import { validateSession } from "@/lib/auth"
import { EncryptionService } from "@/lib/encryption"
import { SecurityService } from "@/lib/security"
import { sql } from "@/lib/database"
import { z } from "zod"

const encryptDocumentSchema = z.object({
  projectId: z.string().uuid(),
  filename: z.string().min(1).max(255),
  content: z.string().min(1),
  accessLevel: z.enum(["private", "team", "public"]).default("private"),
})

export async function POST(request: NextRequest) {
  try {
    const sessionToken = request.cookies.get("session-token")?.value
    if (!sessionToken) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const session = await validateSession(sessionToken)
    if (!session) {
      return NextResponse.json({ error: "Invalid session" }, { status: 401 })
    }

    // Rate limiting
    const rateLimit = await SecurityService.checkRateLimit(session.userId, "encrypt_document")

    if (!rateLimit.allowed) {
      return NextResponse.json({ error: "Rate limit exceeded", resetTime: rateLimit.resetTime }, { status: 429 })
    }

    const body = await request.json()
    const { projectId, filename, content, accessLevel } = encryptDocumentSchema.parse(body)

    // Verify user has access to the project
    const [project] = await sql`
      SELECT creator_id FROM projects WHERE id = ${projectId}
    `

    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 })
    }

    if (project.creator_id !== session.userId) {
      return NextResponse.json({ error: "Access denied" }, { status: 403 })
    }

    // Sanitize filename
    const sanitizedFilename = SecurityService.sanitizeInput(filename)

    // Generate encryption password (in production, use user's master key)
    const encryptionPassword = EncryptionService.generateSecureToken(32)

    // Encrypt document content
    const encryptedContent = await EncryptionService.encrypt(content, encryptionPassword)
    const contentHash = await EncryptionService.hashData(content)

    // Store encrypted document
    const [document] = await sql`
      INSERT INTO encrypted_documents (
        project_id, user_id, filename, content_encrypted, content_hash, access_level
      )
      VALUES (
        ${projectId}, ${session.userId}, ${sanitizedFilename}, 
        ${encryptedContent}, ${contentHash}, ${accessLevel}
      )
      RETURNING id, filename, access_level, created_at
    `

    // Log security event
    await SecurityService.logSecurityEvent({
      userId: session.userId,
      action: "document_encrypted",
      resourceType: "document",
      resourceId: document.id,
      ipAddress: request.ip,
      userAgent: request.headers.get("user-agent") || undefined,
      success: true,
      metadata: { filename: sanitizedFilename, accessLevel },
    })

    return NextResponse.json({
      document: {
        id: document.id,
        filename: document.filename,
        accessLevel: document.access_level,
        createdAt: document.created_at,
      },
      encryptionKey: encryptionPassword, // In production, store securely
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: "Validation failed", details: error.errors }, { status: 400 })
    }

    console.error("Document encryption error:", error)
    return NextResponse.json({ error: "Encryption failed" }, { status: 500 })
  }
}
