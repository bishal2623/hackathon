import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { data, password } = await request.json()

    if (!data || !password) {
      return NextResponse.json({ error: "Data and password are required" }, { status: 400 })
    }

    // Check if Pinata JWT is configured
    const pinataJWT = process.env.PINATA_JWT
    if (!pinataJWT) {
      return NextResponse.json({ error: "IPFS service not configured" }, { status: 500 })
    }

    // Simple encryption for demo purposes
    // In production, use proper encryption libraries
    const encrypted = btoa(JSON.stringify(data) + "::" + password)
    const encryptedData = { encrypted: true, data: encrypted }

    // Upload encrypted JSON to Pinata
    const response = await fetch("https://api.pinata.cloud/pinning/pinJSONToIPFS", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${pinataJWT}`,
      },
      body: JSON.stringify({
        pinataContent: encryptedData,
        pinataMetadata: {
          name: "GrayHub Encrypted Project Metadata",
          keyvalues: {
            uploadedBy: "GrayHub",
            encrypted: "true",
            timestamp: new Date().toISOString(),
          },
        },
      }),
    })

    if (!response.ok) {
      throw new Error(`Pinata API error: ${response.status}`)
    }

    const result = await response.json()

    return NextResponse.json({
      ipfsHash: `ipfs://${result.IpfsHash}`,
      pinataUrl: `https://gateway.pinata.cloud/ipfs/${result.IpfsHash}`,
    })
  } catch (error) {
    console.error("Error uploading encrypted data to IPFS:", error)
    return NextResponse.json({ error: "Failed to upload encrypted data to IPFS" }, { status: 500 })
  }
}
