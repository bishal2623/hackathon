import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { data } = await request.json()

    if (!data) {
      return NextResponse.json({ error: "No data provided" }, { status: 400 })
    }

    // Check if Pinata JWT is configured
    const pinataJWT = process.env.PINATA_JWT
    if (!pinataJWT) {
      return NextResponse.json({ error: "IPFS service not configured" }, { status: 500 })
    }

    // Upload JSON to Pinata
    const response = await fetch("https://api.pinata.cloud/pinning/pinJSONToIPFS", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${pinataJWT}`,
      },
      body: JSON.stringify({
        pinataContent: data,
        pinataMetadata: {
          name: "GrayHub Project Metadata",
          keyvalues: {
            uploadedBy: "GrayHub",
            timestamp: new Date().toISOString(),
          },
        },
      }),
    })

    if (!response.ok) {
      throw new Error(`Pinata API error: ${response.status}`)
    }

    const result = await response.json()

    return NextResponse.json({
      ipfsHash: `ipfs://${result.IpfsHash}`,
      pinataUrl: `https://gateway.pinata.cloud/ipfs/${result.IpfsHash}`,
    })
  } catch (error) {
    console.error("Error uploading JSON to IPFS:", error)
    return NextResponse.json({ error: "Failed to upload JSON to IPFS" }, { status: 500 })
  }
}
