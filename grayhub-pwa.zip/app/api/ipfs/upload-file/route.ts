import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get("file") as File

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    // Check if Pinata JWT is configured
    const pinataJWT = process.env.PINATA_JWT
    if (!pinataJWT) {
      return NextResponse.json({ error: "IPFS service not configured" }, { status: 500 })
    }

    // Create form data for Pinata
    const pinataFormData = new FormData()
    pinataFormData.append("file", file)

    const metadata = JSON.stringify({
      name: file.name,
      keyvalues: {
        uploadedBy: "GrayHub",
        timestamp: new Date().toISOString(),
      },
    })
    pinataFormData.append("pinataMetadata", metadata)

    const options = JSON.stringify({
      cidVersion: 0,
    })
    pinataFormData.append("pinataOptions", options)

    // Upload to Pinata
    const response = await fetch("https://api.pinata.cloud/pinning/pinFileToIPFS", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${pinataJWT}`,
      },
      body: pinataFormData,
    })

    if (!response.ok) {
      throw new Error(`Pinata API error: ${response.status}`)
    }

    const result = await response.json()

    return NextResponse.json({
      ipfsHash: `ipfs://${result.IpfsHash}`,
      pinataUrl: `https://gateway.pinata.cloud/ipfs/${result.IpfsHash}`,
    })
  } catch (error) {
    console.error("Error uploading file to IPFS:", error)
    return NextResponse.json({ error: "Failed to upload file to IPFS" }, { status: 500 })
  }
}
