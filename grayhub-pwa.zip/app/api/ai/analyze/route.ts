import { type NextRequest, NextResponse } from "next/server"
import { validateSession } from "@/lib/auth"
import { sql } from "@/lib/database"
import { z } from "zod"

const analyzeSchema = z.object({
  projectId: z.string().uuid(),
  analysisType: z.enum(["novelty", "plagiarism", "market_potential", "technical_feasibility"]),
  content: z.string().min(100),
  additionalData: z.object({}).optional(),
})

// Mock AI analysis - replace with real AI service
async function performAIAnalysis(type: string, content: string, additionalData?: any) {
  // Simulate processing time
  await new Promise((resolve) => setTimeout(resolve, 2000))

  const baseScore = Math.random() * 0.4 + 0.6 // 0.6-1.0 range

  switch (type) {
    case "novelty":
      return {
        score: baseScore,
        confidence: 0.85,
        details: {
          uniqueness: baseScore * 0.9,
          innovation: baseScore * 1.1,
          priorArt: Math.max(0, 1 - baseScore),
          keyNovelties: [
            "Novel approach to data processing",
            "Innovative user interface design",
            "Unique algorithmic implementation",
          ],
        },
        heatmap: generateNoveltyHeatmap(content),
      }

    case "plagiarism":
      const plagiarismScore = Math.random() * 0.3 // Low plagiarism
      return {
        score: plagiarismScore,
        confidence: 0.92,
        details: {
          similarityMatches: [
            {
              source: "Patent US10123456",
              similarity: plagiarismScore * 0.8,
              matchedSections: ["Abstract", "Claims 1-3"],
            },
          ],
          riskLevel: plagiarismScore < 0.1 ? "low" : plagiarismScore < 0.3 ? "medium" : "high",
        },
      }

    case "market_potential":
      return {
        score: baseScore,
        confidence: 0.78,
        details: {
          marketSize: "$2.5B",
          growthRate: "15% CAGR",
          competitiveAdvantage: baseScore * 0.9,
          targetMarkets: ["Enterprise Software", "Healthcare", "Finance"],
        },
      }

    case "technical_feasibility":
      return {
        score: baseScore,
        confidence: 0.88,
        details: {
          implementationComplexity: 1 - baseScore,
          resourceRequirements: "Medium",
          technicalRisks: ["Scalability challenges", "Integration complexity"],
          recommendedApproach: "Phased implementation with MVP first",
        },
      }

    default:
      throw new Error("Unknown analysis type")
  }
}

function generateNoveltyHeatmap(content: string) {
  const sentences = content.split(/[.!?]+/).filter((s) => s.trim().length > 0)
  return sentences.map((sentence, index) => ({
    text: sentence.trim(),
    noveltyScore: Math.random() * 0.4 + 0.6,
    position: index,
  }))
}

export async function POST(request: NextRequest) {
  try {
    const sessionToken = request.cookies.get("session-token")?.value
    if (!sessionToken) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const session = await validateSession(sessionToken)
    if (!session) {
      return NextResponse.json({ error: "Invalid session" }, { status: 401 })
    }

    const body = await request.json()
    const { projectId, analysisType, content, additionalData } = analyzeSchema.parse(body)

    // Verify user has access to the project
    const [project] = await sql`
      SELECT creator_id FROM projects WHERE id = ${projectId}
    `

    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 })
    }

    if (project.creator_id !== session.userId) {
      return NextResponse.json({ error: "Access denied" }, { status: 403 })
    }

    const startTime = Date.now()

    // Perform AI analysis
    const results = await performAIAnalysis(analysisType, content, additionalData)

    const processingTime = Date.now() - startTime

    // Store analysis results
    const [analysis] = await sql`
      INSERT INTO ai_analyses (
        project_id, analysis_type, model_version, input_data, results, 
        confidence_score, processing_time_ms
      )
      VALUES (
        ${projectId}, ${analysisType}, 'v2.1', 
        ${JSON.stringify({ content, additionalData })},
        ${JSON.stringify(results)}, ${results.confidence}, ${processingTime}
      )
      RETURNING *
    `

    // Update project with analysis results
    if (analysisType === "novelty") {
      await sql`
        UPDATE projects 
        SET ai_novelty_score = ${results.score}
        WHERE id = ${projectId}
      `
    } else if (analysisType === "plagiarism") {
      await sql`
        UPDATE projects 
        SET plagiarism_score = ${results.score}
        WHERE id = ${projectId}
      `
    }

    return NextResponse.json({
      analysisId: analysis.id,
      type: analysisType,
      results,
      processingTime,
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: "Validation failed", details: error.errors }, { status: 400 })
    }

    console.error("AI analysis error:", error)
    return NextResponse.json({ error: "Analysis failed" }, { status: 500 })
  }
}
