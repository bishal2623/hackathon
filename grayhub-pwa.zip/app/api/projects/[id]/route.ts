import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/database"
import { validateSession, logSecurityEvent } from "@/lib/auth"
import { z } from "zod"

const updateProjectSchema = z.object({
  title: z.string().min(1).max(200).optional(),
  description: z.string().min(10).max(1000).optional(),
  detailedDescription: z.string().optional(),
  category: z.string().optional(),
  tags: z.array(z.string()).max(10).optional(),
  status: z.enum(["draft", "active", "completed", "archived"]).optional(),
  visibility: z.enum(["public", "private", "unlisted"]).optional(),
})

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const [project] = await sql`
      SELECT p.*, u.username as creator_username, u.display_name as creator_name,
             u.avatar_url as creator_avatar, u.bio as creator_bio
      FROM projects p
      JOIN users u ON p.creator_id = u.id
      WHERE p.id = ${params.id}
    `

    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 })
    }

    // Check if user has access to private projects
    if (project.visibility === "private") {
      const sessionToken = request.cookies.get("session-token")?.value
      if (!sessionToken) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
      }

      const session = await validateSession(sessionToken)
      if (!session || session.userId !== project.creator_id) {
        return NextResponse.json({ error: "Access denied" }, { status: 403 })
      }
    }

    // Get collaborators
    const collaborators = await sql`
      SELECT pc.role, pc.equity_share, pc.joined_at,
             u.username, u.display_name, u.avatar_url
      FROM project_collaborators pc
      JOIN users u ON pc.user_id = u.id
      WHERE pc.project_id = ${params.id}
    `

    return NextResponse.json({
      project: { ...project, collaborators },
    })
  } catch (error) {
    console.error("Get project error:", error)
    return NextResponse.json({ error: "Failed to fetch project" }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const sessionToken = request.cookies.get("session-token")?.value
    if (!sessionToken) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const session = await validateSession(sessionToken)
    if (!session) {
      return NextResponse.json({ error: "Invalid session" }, { status: 401 })
    }

    // Check if user owns the project
    const [project] = await sql`
      SELECT creator_id FROM projects WHERE id = ${params.id}
    `

    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 })
    }

    if (project.creator_id !== session.userId) {
      return NextResponse.json({ error: "Access denied" }, { status: 403 })
    }

    const body = await request.json()
    const validatedData = updateProjectSchema.parse(body)

    // Build update query dynamically
    const updateFields = Object.entries(validatedData)
      .filter(([_, value]) => value !== undefined)
      .map(([key, _], index) => `${key} = $${index + 2}`)
      .join(", ")

    if (updateFields.length === 0) {
      return NextResponse.json({ error: "No fields to update" }, { status: 400 })
    }

    const values = Object.values(validatedData).filter((v) => v !== undefined)

    const [updatedProject] = await sql`
      UPDATE projects 
      SET ${sql.unsafe(updateFields)}, updated_at = NOW()
      WHERE id = ${params.id}
      RETURNING *
    `

    await logSecurityEvent({
      userId: session.userId,
      action: "project_updated",
      resourceType: "project",
      resourceId: params.id,
      ipAddress: request.ip,
      userAgent: request.headers.get("user-agent") || undefined,
      metadata: { updatedFields: Object.keys(validatedData) },
    })

    return NextResponse.json({ project: updatedProject })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: "Validation failed", details: error.errors }, { status: 400 })
    }

    console.error("Update project error:", error)
    return NextResponse.json({ error: "Failed to update project" }, { status: 500 })
  }
}
