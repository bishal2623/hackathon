import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/database"
import { validateSession, logSecurityEvent } from "@/lib/auth"
import { z } from "zod"

const createProjectSchema = z.object({
  title: z.string().min(1).max(200),
  description: z.string().min(10).max(1000),
  detailedDescription: z.string().optional(),
  category: z.string().min(1),
  tags: z.array(z.string()).max(10),
  visibility: z.enum(["public", "private", "unlisted"]).default("public"),
  licenseType: z.string().optional(),
  collaborationSettings: z
    .object({
      allowCollaborators: z.boolean().default(true),
      requireApproval: z.boolean().default(true),
      maxCollaborators: z.number().max(50).default(10),
    })
    .optional(),
})

export async function POST(request: NextRequest) {
  try {
    const sessionToken = request.cookies.get("session-token")?.value
    if (!sessionToken) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const session = await validateSession(sessionToken)
    if (!session) {
      return NextResponse.json({ error: "Invalid session" }, { status: 401 })
    }

    const body = await request.json()
    const validatedData = createProjectSchema.parse(body)

    const project = await sql`
      INSERT INTO projects (
        creator_id, title, description, detailed_description, category, tags, 
        visibility, license_type, collaboration_settings
      )
      VALUES (
        ${session.userId}, ${validatedData.title}, ${validatedData.description},
        ${validatedData.detailedDescription}, ${validatedData.category}, ${validatedData.tags},
        ${validatedData.visibility}, ${validatedData.licenseType}, 
        ${JSON.stringify(validatedData.collaborationSettings || {})}
      )
      RETURNING *
    `

    await logSecurityEvent({
      userId: session.userId,
      action: "project_created",
      resourceType: "project",
      resourceId: project[0].id,
      ipAddress: request.ip,
      userAgent: request.headers.get("user-agent") || undefined,
    })

    return NextResponse.json({ project: project[0] }, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: "Validation failed", details: error.errors }, { status: 400 })
    }

    console.error("Create project error:", error)
    return NextResponse.json({ error: "Failed to create project" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get("category")
    const search = searchParams.get("search")
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Math.min(Number.parseInt(searchParams.get("limit") || "20"), 50)
    const offset = (page - 1) * limit

    let query = `
      SELECT p.*, u.username as creator_username, u.display_name as creator_name,
             u.avatar_url as creator_avatar
      FROM projects p
      JOIN users u ON p.creator_id = u.id
      WHERE p.visibility = 'public'
    `
    const params: any[] = []

    if (category) {
      query += ` AND p.category = $${params.length + 1}`
      params.push(category)
    }

    if (search) {
      query += ` AND (p.title ILIKE $${params.length + 1} OR p.description ILIKE $${params.length + 1})`
      params.push(`%${search}%`)
    }

    query += ` ORDER BY p.created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`
    params.push(limit, offset)

    const projects = await sql(query, params)

    return NextResponse.json({ projects, page, limit })
  } catch (error) {
    console.error("Get projects error:", error)
    return NextResponse.json({ error: "Failed to fetch projects" }, { status: 500 })
  }
}
