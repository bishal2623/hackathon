import { type NextRequest, NextResponse } from "next/server"
import { createUser, getUserByWallet, logSecurityEvent } from "@/lib/database"
import { createSession, detectSuspiciousActivity } from "@/lib/auth"
import { verifyMessage } from "viem"

export async function POST(request: NextRequest) {
  try {
    const { walletAddress, signature, message, userData } = await request.json()

    if (!walletAddress || !signature || !message) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Verify wallet signature
    const isValid = await verifyMessage({
      address: walletAddress as `0x${string}`,
      message,
      signature: signature as `0x${string}`,
    })

    if (!isValid) {
      await logSecurityEvent({
        action: "wallet_auth_failed",
        ipAddress: request.ip,
        userAgent: request.headers.get("user-agent") || undefined,
        riskScore: 50,
        metadata: { walletAddress, reason: "invalid_signature" },
      })

      return NextResponse.json({ error: "Invalid signature" }, { status: 401 })
    }

    // Get or create user
    let user = await getUserByWallet(walletAddress)
    if (!user) {
      user = await createUser({
        walletAddress,
        ...userData,
      })
    }

    // Check for suspicious activity
    const riskScore = await detectSuspiciousActivity(user.id, request.ip)

    if (riskScore > 70) {
      await logSecurityEvent({
        userId: user.id,
        action: "high_risk_login_blocked",
        ipAddress: request.ip,
        userAgent: request.headers.get("user-agent") || undefined,
        riskScore,
        metadata: { walletAddress },
      })

      return NextResponse.json({ error: "Account temporarily locked due to suspicious activity" }, { status: 423 })
    }

    // Create session
    const session = await createSession(user.id, signature, request.ip, request.headers.get("user-agent") || undefined)

    // Set secure cookie
    const response = NextResponse.json({
      user: {
        id: user.id,
        walletAddress: user.wallet_address,
        username: user.username,
        displayName: user.display_name,
        verificationLevel: user.verification_level,
      },
      session: {
        token: session.sessionToken,
        expiresAt: session.expiresAt,
      },
    })

    response.cookies.set("session-token", session.sessionToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge: 7 * 24 * 60 * 60, // 7 days
    })

    return response
  } catch (error) {
    console.error("Wallet auth error:", error)
    return NextResponse.json({ error: "Authentication failed" }, { status: 500 })
  }
}
