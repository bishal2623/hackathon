import { type NextRequest, NextResponse } from "next/server"
import { validateSession, logSecurityEvent } from "@/lib/auth"
import { sql } from "@/lib/database"
import { z } from "zod"

const updateProfileSchema = z.object({
  displayName: z.string().min(1).max(100).optional(),
  bio: z.string().max(500).optional(),
  location: z.string().max(100).optional(),
  websiteUrl: z.string().url().optional().or(z.literal("")),
  twitterHandle: z.string().max(50).optional(),
  linkedinUrl: z.string().url().optional().or(z.literal("")),
  githubUsername: z.string().max(50).optional(),
  privacySettings: z
    .object({
      showEmail: z.boolean().default(false),
      showLocation: z.boolean().default(true),
      showProjects: z.boolean().default(true),
      allowMessages: z.boolean().default(true),
    })
    .optional(),
  notificationPreferences: z
    .object({
      emailNotifications: z.boolean().default(true),
      projectUpdates: z.boolean().default(true),
      collaborationRequests: z.boolean().default(true),
      marketingEmails: z.boolean().default(false),
    })
    .optional(),
})

export async function GET(request: NextRequest) {
  try {
    const sessionToken = request.cookies.get("session-token")?.value
    if (!sessionToken) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const session = await validateSession(sessionToken)
    if (!session) {
      return NextResponse.json({ error: "Invalid session" }, { status: 401 })
    }

    const [user] = await sql`
      SELECT id, wallet_address, email, username, display_name, bio, avatar_url,
             cover_image_url, location, website_url, twitter_handle, linkedin_url,
             github_username, reputation_score, verification_level, kyc_status,
             privacy_settings, notification_preferences, created_at, last_active_at
      FROM users 
      WHERE id = ${session.userId}
    `

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    // Get user's project statistics
    const [stats] = await sql`
      SELECT 
        COUNT(*) as total_projects,
        COUNT(CASE WHEN status = 'active' THEN 1 END) as active_projects,
        COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_projects,
        AVG(ai_novelty_score) as avg_novelty_score
      FROM projects 
      WHERE creator_id = ${session.userId}
    `

    return NextResponse.json({
      user: {
        ...user,
        stats: stats || {
          total_projects: 0,
          active_projects: 0,
          completed_projects: 0,
          avg_novelty_score: null,
        },
      },
    })
  } catch (error) {
    console.error("Get profile error:", error)
    return NextResponse.json({ error: "Failed to fetch profile" }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const sessionToken = request.cookies.get("session-token")?.value
    if (!sessionToken) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const session = await validateSession(sessionToken)
    if (!session) {
      return NextResponse.json({ error: "Invalid session" }, { status: 401 })
    }

    const body = await request.json()
    const validatedData = updateProfileSchema.parse(body)

    // Build update query dynamically
    const updateFields = Object.entries(validatedData)
      .filter(([_, value]) => value !== undefined)
      .map(([key, _], index) => {
        if (key === "privacySettings" || key === "notificationPreferences") {
          return `${key} = $${index + 2}::jsonb`
        }
        return `${key} = $${index + 2}`
      })
      .join(", ")

    if (updateFields.length === 0) {
      return NextResponse.json({ error: "No fields to update" }, { status: 400 })
    }

    const values = Object.values(validatedData)
      .filter((v) => v !== undefined)
      .map((v) => (typeof v === "object" ? JSON.stringify(v) : v))

    const [updatedUser] = await sql`
      UPDATE users 
      SET ${sql.unsafe(updateFields)}, updated_at = NOW()
      WHERE id = ${session.userId}
      RETURNING *
    `

    await logSecurityEvent({
      userId: session.userId,
      action: "profile_updated",
      resourceType: "user",
      resourceId: session.userId,
      ipAddress: request.ip,
      userAgent: request.headers.get("user-agent") || undefined,
      metadata: { updatedFields: Object.keys(validatedData) },
    })

    return NextResponse.json({ user: updatedUser })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: "Validation failed", details: error.errors }, { status: 400 })
    }

    console.error("Update profile error:", error)
    return NextResponse.json({ error: "Failed to update profile" }, { status: 500 })
  }
}
