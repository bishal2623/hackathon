import type React from "react"
import type { Metadata } from "next"
import { GeistSans } from "geist/font/sans"
import { GeistMono } from "geist/font/mono"
import { Analytics } from "@vercel/analytics/next"
import { Suspense } from "react"
import { Providers } from "./providers"
import "./globals.css"

export const metadata: Metadata = {
  title: "GrayHub - Student NFT Hub",
  description: "Transform student innovations into NFTs with blockchain technology",
  generator: "GrayHub",
  manifest: "/manifest.json",
  keywords: ["blockchain", "NFT", "students", "innovation", "Web3", "education"],
  authors: [{ name: "GrayHub Team" }],
  creator: "GrayHub",
  publisher: "GrayHub",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL("https://grayhub.vercel.app"),
  alternates: {
    canonical: "/",
  },
  openGraph: {
    title: "GrayHub - Student NFT Hub",
    description: "Transform student innovations into NFTs with blockchain technology",
    url: "https://grayhub.vercel.app",
    siteName: "GrayHub",
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "GrayHub - Student NFT Hub",
    description: "Transform student innovations into NFTs with blockchain technology",
    creator: "@grayhub",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  verification: {
    google: "google-site-verification-token",
  },
}

export const viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#6C63FF" },
    { media: "(prefers-color-scheme: dark)", color: "#1E2A78" },
  ],
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/icons/icon-192x192.png" />
        <link rel="apple-touch-icon" href="/icons/icon-192x192.png" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="GrayHub" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="msapplication-config" content="/browserconfig.xml" />
        <meta name="msapplication-TileColor" content="#6C63FF" />
        <meta name="msapplication-tap-highlight" content="no" />
      </head>
      <body className={`font-sans ${GeistSans.variable} ${GeistMono.variable} antialiased`}>
        <Suspense fallback={null}>
          <Providers>
            {children}
            <Analytics />
          </Providers>
        </Suspense>
      </body>
    </html>
  )
}
