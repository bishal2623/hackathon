"use client"

import { useState } from "react"
import { Navbar } from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { ChatInterface } from "@/components/chat-interface"
import {
  Users,
  MessageCircle,
  Calendar,
  Search,
  Plus,
  Filter,
  CheckCircle,
  Clock,
  AlertCircle,
  Award,
} from "lucide-react"

// Mock collaboration data
const mockCollaborations = [
  {
    id: "1",
    title: "Blockchain Voting Platform",
    description: "Building a secure, transparent voting system with zero-knowledge proofs",
    status: "active",
    members: [
      { name: "Alex Rodriguez", address: "0x1234...5678", role: "Lead Developer", avatar: "" },
      { name: "Maya Patel", address: "0x5678...9012", role: "Cryptography Expert", avatar: "" },
      { name: "Sarah Chen", address: "0x9012...3456", role: "UI/UX Designer", avatar: "" },
    ],
    progress: 65,
    deadline: "2024-03-15",
    category: "Blockchain & Security",
    tasks: {
      total: 12,
      completed: 8,
      inProgress: 3,
      pending: 1,
    },
    lastActivity: "2 hours ago",
  },
  {
    id: "2",
    title: "AI-Powered Medical Diagnosis",
    description: "Developing machine learning models for early disease detection",
    status: "planning",
    members: [
      { name: "David Kim", address: "0x3456...7890", role: "ML Engineer", avatar: "" },
      { name: "Emma Johnson", address: "0x7890...1234", role: "Medical Advisor", avatar: "" },
    ],
    progress: 25,
    deadline: "2024-04-20",
    category: "AI & Healthcare",
    tasks: {
      total: 8,
      completed: 2,
      inProgress: 2,
      pending: 4,
    },
    lastActivity: "1 day ago",
  },
  {
    id: "3",
    title: "Sustainable Energy Grid",
    description: "Smart grid optimization using IoT and renewable energy sources",
    status: "completed",
    members: [
      { name: "James Wilson", address: "0x1111...2222", role: "IoT Specialist", avatar: "" },
      { name: "Lisa Zhang", address: "0x2222...3333", role: "Energy Engineer", avatar: "" },
      { name: "Mike Brown", address: "0x3333...4444", role: "Data Scientist", avatar: "" },
    ],
    progress: 100,
    deadline: "2024-02-28",
    category: "Sustainability",
    tasks: {
      total: 15,
      completed: 15,
      inProgress: 0,
      pending: 0,
    },
    lastActivity: "1 week ago",
  },
]

const mockCollaborationRequests = [
  {
    id: "req-1",
    from: {
      name: "Tom Anderson",
      address: "0x4444...5555",
      grayScore: 78,
      avatar: "",
    },
    project: "Quantum Computing Simulator",
    message:
      "Hi! I saw your quantum computing expertise and would love to collaborate on my simulator project. Looking for someone with your background in quantum algorithms.",
    timestamp: "3 hours ago",
    skills: ["Quantum Computing", "Python", "Mathematics"],
  },
  {
    id: "req-2",
    from: {
      name: "Anna Lee",
      address: "0x5555...6666",
      grayScore: 85,
      avatar: "",
    },
    project: "DeFi Lending Protocol",
    message:
      "Your smart contract security expertise would be perfect for our DeFi project. We're building a novel lending protocol and need security auditing.",
    timestamp: "1 day ago",
    skills: ["Solidity", "DeFi", "Security Auditing"],
  },
]

export default function CollaboratePage() {
  const [activeTab, setActiveTab] = useState("active")
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCollaboration, setSelectedCollaboration] = useState<string | null>(null)

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800"
      case "planning":
        return "bg-blue-100 text-blue-800"
      case "completed":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "active":
        return <CheckCircle className="w-4 h-4" />
      case "planning":
        return <Clock className="w-4 h-4" />
      case "completed":
        return <CheckCircle className="w-4 h-4" />
      default:
        return <AlertCircle className="w-4 h-4" />
    }
  }

  return (
    <div className="min-h-screen grayhub-gradient">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">Collaboration Hub</h1>
            <p className="text-xl text-gray-600">Work together on innovative projects</p>
          </div>
          <div className="flex items-center gap-4 mt-4 md:mt-0">
            <Button className="bg-[#6C63FF] text-white hover:bg-[#1E2A78]">
              <Plus className="w-4 h-4 mr-2" />
              Start Collaboration
            </Button>
          </div>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
              <div className="flex items-center justify-between">
                <TabsList className="grid w-full max-w-md grid-cols-3">
                  <TabsTrigger value="active">Active</TabsTrigger>
                  <TabsTrigger value="requests">Requests</TabsTrigger>
                  <TabsTrigger value="find">Find Partners</TabsTrigger>
                </TabsList>

                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Search collaborations..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10 w-64"
                    />
                  </div>
                  <Button variant="outline">
                    <Filter className="w-4 h-4 mr-2" />
                    Filter
                  </Button>
                </div>
              </div>

              {/* Active Collaborations */}
              <TabsContent value="active" className="space-y-6">
                <div className="grid gap-6">
                  {mockCollaborations.map((collab) => (
                    <Card key={collab.id} className="grayhub-card-glow">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <h3 className="text-xl font-semibold text-gray-900">{collab.title}</h3>
                              <Badge className={getStatusColor(collab.status)}>
                                {getStatusIcon(collab.status)}
                                <span className="ml-1 capitalize">{collab.status}</span>
                              </Badge>
                              <Badge variant="outline" className="text-[#6C63FF] border-[#6C63FF]">
                                {collab.category}
                              </Badge>
                            </div>
                            <p className="text-gray-600 mb-4">{collab.description}</p>

                            {/* Progress */}
                            <div className="mb-4">
                              <div className="flex items-center justify-between mb-2">
                                <span className="text-sm font-medium text-gray-700">Progress</span>
                                <span className="text-sm text-gray-600">{collab.progress}%</span>
                              </div>
                              <div className="w-full bg-gray-200 rounded-full h-2">
                                <div
                                  className="bg-[#6C63FF] h-2 rounded-full transition-all duration-300"
                                  style={{ width: `${collab.progress}%` }}
                                ></div>
                              </div>
                            </div>

                            {/* Task Summary */}
                            <div className="flex items-center gap-6 text-sm text-gray-600 mb-4">
                              <div className="flex items-center">
                                <CheckCircle className="w-4 h-4 text-green-600 mr-1" />
                                {collab.tasks.completed} completed
                              </div>
                              <div className="flex items-center">
                                <Clock className="w-4 h-4 text-blue-600 mr-1" />
                                {collab.tasks.inProgress} in progress
                              </div>
                              <div className="flex items-center">
                                <AlertCircle className="w-4 h-4 text-gray-400 mr-1" />
                                {collab.tasks.pending} pending
                              </div>
                              <div className="flex items-center">
                                <Calendar className="w-4 h-4 text-gray-600 mr-1" />
                                Due {new Date(collab.deadline).toLocaleDateString()}
                              </div>
                            </div>

                            {/* Members */}
                            <div className="flex items-center justify-between">
                              <div className="flex items-center">
                                <div className="flex -space-x-2 mr-3">
                                  {collab.members.slice(0, 3).map((member, index) => (
                                    <Avatar key={index} className="w-8 h-8 border-2 border-white">
                                      <AvatarFallback className="bg-gradient-to-br from-[#6C63FF] to-[#1E2A78] text-white text-xs">
                                        {member.name
                                          .split(" ")
                                          .map((n) => n[0])
                                          .join("")}
                                      </AvatarFallback>
                                    </Avatar>
                                  ))}
                                  {collab.members.length > 3 && (
                                    <div className="w-8 h-8 rounded-full bg-gray-200 border-2 border-white flex items-center justify-center">
                                      <span className="text-xs text-gray-600">+{collab.members.length - 3}</span>
                                    </div>
                                  )}
                                </div>
                                <span className="text-sm text-gray-600">{collab.members.length} members</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Button variant="outline" size="sm" onClick={() => setSelectedCollaboration(collab.id)}>
                                  <MessageCircle className="w-4 h-4 mr-2" />
                                  Chat
                                </Button>
                                <Button variant="outline" size="sm">
                                  View Board
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              {/* Collaboration Requests */}
              <TabsContent value="requests" className="space-y-6">
                <div className="grid gap-6">
                  {mockCollaborationRequests.map((request) => (
                    <Card key={request.id} className="grayhub-card-glow">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center mb-3">
                              <Avatar className="w-10 h-10 mr-3">
                                <AvatarFallback className="bg-gradient-to-br from-[#6C63FF] to-[#1E2A78] text-white">
                                  {request.from.name
                                    .split(" ")
                                    .map((n) => n[0])
                                    .join("")}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="flex items-center gap-2">
                                  <h4 className="font-semibold text-gray-900">{request.from.name}</h4>
                                  <Badge className="bg-[#6C63FF]/10 text-[#6C63FF]">{request.from.grayScore}</Badge>
                                </div>
                                <p className="text-sm text-gray-500 font-mono">{request.from.address}</p>
                              </div>
                            </div>

                            <h3 className="text-lg font-semibold text-gray-900 mb-2">
                              Collaboration Request: {request.project}
                            </h3>
                            <p className="text-gray-700 mb-4">{request.message}</p>

                            <div className="flex flex-wrap gap-2 mb-4">
                              {request.skills.map((skill) => (
                                <Badge key={skill} variant="outline" className="text-gray-600">
                                  {skill}
                                </Badge>
                              ))}
                            </div>

                            <div className="flex items-center justify-between">
                              <span className="text-sm text-gray-500">{request.timestamp}</span>
                              <div className="flex items-center gap-2">
                                <Button variant="outline" size="sm">
                                  Decline
                                </Button>
                                <Button size="sm" className="bg-[#6C63FF] text-white hover:bg-[#1E2A78]">
                                  Accept
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              {/* Find Partners */}
              <TabsContent value="find" className="space-y-6">
                <div className="text-center py-12">
                  <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Find Collaboration Partners</h3>
                  <p className="text-gray-600 mb-6">
                    Connect with other innovators who share your interests and expertise
                  </p>
                  <Button className="bg-[#6C63FF] text-white hover:bg-[#1E2A78]">Browse Developers</Button>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Stats */}
            <Card className="grayhub-card-glow">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Award className="w-5 h-5 mr-2 text-[#6C63FF]" />
                  Your Stats
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Active Collaborations</span>
                    <span className="font-semibold text-[#6C63FF]">2</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Completed Projects</span>
                    <span className="font-semibold text-gray-900">5</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Success Rate</span>
                    <span className="font-semibold text-green-600">94%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Avg Rating</span>
                    <span className="font-semibold text-yellow-600">4.8/5</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card className="grayhub-card-glow">
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2 mr-3"></div>
                    <div>
                      <p className="text-sm font-medium text-gray-900">Task completed</p>
                      <p className="text-xs text-gray-600">Blockchain Voting Platform</p>
                      <p className="text-xs text-gray-500">2 hours ago</p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3"></div>
                    <div>
                      <p className="text-sm font-medium text-gray-900">New message</p>
                      <p className="text-xs text-gray-600">From Alex Rodriguez</p>
                      <p className="text-xs text-gray-500">4 hours ago</p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 mr-3"></div>
                    <div>
                      <p className="text-sm font-medium text-gray-900">Collaboration request</p>
                      <p className="text-xs text-gray-600">Quantum Computing project</p>
                      <p className="text-xs text-gray-500">1 day ago</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Chat Interface Modal */}
        {selectedCollaboration && (
          <ChatInterface collaborationId={selectedCollaboration} onClose={() => setSelectedCollaboration(null)} />
        )}
      </div>
    </div>
  )
}
