"use client"

import { useState } from "react"
import { Navbar } from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { User, Bell, Shield, Globe, Save, X, Plus, Github, Twitter, Mail } from "lucide-react"

export default function SettingsPage() {
  const [profile, setProfile] = useState({
    name: "Sarah Chen",
    bio: "Full-stack developer and AI researcher passionate about sustainable technology and blockchain innovation.",
    location: "Boston, MA",
    website: "https://sarahchen.dev",
    twitter: "@sarahchen_dev",
    github: "sarahchen",
    email: "sarah@example.com",
  })

  const [skills, setSkills] = useState(["Machine Learning", "Blockchain", "IoT", "React", "Python", "Solidity"])
  const [newSkill, setNewSkill] = useState("")

  const [notifications, setNotifications] = useState({
    projectLikes: true,
    newFollowers: true,
    collaborationRequests: true,
    patentScoreUpdates: true,
    marketplaceActivity: false,
    weeklyDigest: true,
  })

  const [privacy, setPrivacy] = useState({
    profileVisibility: "public",
    showEarnings: true,
    showProjects: true,
    allowMessages: true,
    showActivity: true,
  })

  const handleProfileChange = (field: string, value: string) => {
    setProfile((prev) => ({ ...prev, [field]: value }))
  }

  const addSkill = () => {
    if (newSkill.trim() && !skills.includes(newSkill.trim())) {
      setSkills((prev) => [...prev, newSkill.trim()])
      setNewSkill("")
    }
  }

  const removeSkill = (skill: string) => {
    setSkills((prev) => prev.filter((s) => s !== skill))
  }

  const handleNotificationChange = (key: string, value: boolean) => {
    setNotifications((prev) => ({ ...prev, [key]: value }))
  }

  const handlePrivacyChange = (key: string, value: boolean | string) => {
    setPrivacy((prev) => ({ ...prev, [key]: value }))
  }

  return (
    <div className="min-h-screen grayhub-gradient">
      <Navbar />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">Settings</h1>
          <p className="text-xl text-gray-600">Manage your account preferences and privacy settings</p>
        </div>

        <Tabs defaultValue="profile" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
            <TabsTrigger value="privacy">Privacy</TabsTrigger>
            <TabsTrigger value="account">Account</TabsTrigger>
          </TabsList>

          {/* Profile Settings */}
          <TabsContent value="profile" className="space-y-6">
            <Card className="grayhub-card-glow">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <User className="w-5 h-5 mr-2 text-[#6C63FF]" />
                  Profile Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="name">Display Name</Label>
                    <Input
                      id="name"
                      value={profile.name}
                      onChange={(e) => handleProfileChange("name", e.target.value)}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="location">Location</Label>
                    <Input
                      id="location"
                      value={profile.location}
                      onChange={(e) => handleProfileChange("location", e.target.value)}
                      placeholder="City, Country"
                      className="mt-1"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="bio">Bio</Label>
                  <Textarea
                    id="bio"
                    value={profile.bio}
                    onChange={(e) => handleProfileChange("bio", e.target.value)}
                    placeholder="Tell us about yourself..."
                    className="mt-1 min-h-[100px]"
                  />
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium text-gray-900">Social Links</h4>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="website" className="flex items-center">
                        <Globe className="w-4 h-4 mr-2" />
                        Website
                      </Label>
                      <Input
                        id="website"
                        value={profile.website}
                        onChange={(e) => handleProfileChange("website", e.target.value)}
                        placeholder="https://yourwebsite.com"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email" className="flex items-center">
                        <Mail className="w-4 h-4 mr-2" />
                        Email
                      </Label>
                      <Input
                        id="email"
                        value={profile.email}
                        onChange={(e) => handleProfileChange("email", e.target.value)}
                        placeholder="your@email.com"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="github" className="flex items-center">
                        <Github className="w-4 h-4 mr-2" />
                        GitHub
                      </Label>
                      <Input
                        id="github"
                        value={profile.github}
                        onChange={(e) => handleProfileChange("github", e.target.value)}
                        placeholder="username"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="twitter" className="flex items-center">
                        <Twitter className="w-4 h-4 mr-2" />
                        Twitter
                      </Label>
                      <Input
                        id="twitter"
                        value={profile.twitter}
                        onChange={(e) => handleProfileChange("twitter", e.target.value)}
                        placeholder="@username"
                        className="mt-1"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <Label>Skills & Expertise</Label>
                  <div className="mt-2 space-y-3">
                    <div className="flex gap-2">
                      <Input
                        value={newSkill}
                        onChange={(e) => setNewSkill(e.target.value)}
                        placeholder="Add a skill"
                        onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addSkill())}
                      />
                      <Button type="button" onClick={addSkill} size="sm">
                        <Plus className="w-4 h-4" />
                      </Button>
                    </div>
                    {skills.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {skills.map((skill) => (
                          <Badge key={skill} variant="outline" className="text-[#6C63FF] border-[#6C63FF]">
                            {skill}
                            <button
                              type="button"
                              onClick={() => removeSkill(skill)}
                              className="ml-2 text-[#6C63FF] hover:text-[#1E2A78]"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button className="bg-[#6C63FF] text-white hover:bg-[#1E2A78]">
                    <Save className="w-4 h-4 mr-2" />
                    Save Changes
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notification Settings */}
          <TabsContent value="notifications" className="space-y-6">
            <Card className="grayhub-card-glow">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Bell className="w-5 h-5 mr-2 text-[#6C63FF]" />
                  Notification Preferences
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-gray-900">Project Likes</h4>
                      <p className="text-sm text-gray-600">Get notified when someone likes your projects</p>
                    </div>
                    <Switch
                      checked={notifications.projectLikes}
                      onCheckedChange={(checked) => handleNotificationChange("projectLikes", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-gray-900">New Followers</h4>
                      <p className="text-sm text-gray-600">Get notified when someone follows you</p>
                    </div>
                    <Switch
                      checked={notifications.newFollowers}
                      onCheckedChange={(checked) => handleNotificationChange("newFollowers", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-gray-900">Collaboration Requests</h4>
                      <p className="text-sm text-gray-600">Get notified about collaboration invitations</p>
                    </div>
                    <Switch
                      checked={notifications.collaborationRequests}
                      onCheckedChange={(checked) => handleNotificationChange("collaborationRequests", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-gray-900">Patent Score Updates</h4>
                      <p className="text-sm text-gray-600">Get notified when your patent scores change</p>
                    </div>
                    <Switch
                      checked={notifications.patentScoreUpdates}
                      onCheckedChange={(checked) => handleNotificationChange("patentScoreUpdates", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-gray-900">Marketplace Activity</h4>
                      <p className="text-sm text-gray-600">Get notified about sales and offers</p>
                    </div>
                    <Switch
                      checked={notifications.marketplaceActivity}
                      onCheckedChange={(checked) => handleNotificationChange("marketplaceActivity", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-gray-900">Weekly Digest</h4>
                      <p className="text-sm text-gray-600">Receive a weekly summary of your activity</p>
                    </div>
                    <Switch
                      checked={notifications.weeklyDigest}
                      onCheckedChange={(checked) => handleNotificationChange("weeklyDigest", checked)}
                    />
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button className="bg-[#6C63FF] text-white hover:bg-[#1E2A78]">
                    <Save className="w-4 h-4 mr-2" />
                    Save Preferences
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Privacy Settings */}
          <TabsContent value="privacy" className="space-y-6">
            <Card className="grayhub-card-glow">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Shield className="w-5 h-5 mr-2 text-[#6C63FF]" />
                  Privacy & Security
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-gray-900">Show Earnings</h4>
                      <p className="text-sm text-gray-600">Display your total earnings on your profile</p>
                    </div>
                    <Switch
                      checked={privacy.showEarnings}
                      onCheckedChange={(checked) => handlePrivacyChange("showEarnings", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-gray-900">Show Projects</h4>
                      <p className="text-sm text-gray-600">Make your projects visible to other users</p>
                    </div>
                    <Switch
                      checked={privacy.showProjects}
                      onCheckedChange={(checked) => handlePrivacyChange("showProjects", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-gray-900">Allow Messages</h4>
                      <p className="text-sm text-gray-600">Let other users send you direct messages</p>
                    </div>
                    <Switch
                      checked={privacy.allowMessages}
                      onCheckedChange={(checked) => handlePrivacyChange("allowMessages", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-gray-900">Show Activity</h4>
                      <p className="text-sm text-gray-600">Display your recent activity on your profile</p>
                    </div>
                    <Switch
                      checked={privacy.showActivity}
                      onCheckedChange={(checked) => handlePrivacyChange("showActivity", checked)}
                    />
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button className="bg-[#6C63FF] text-white hover:bg-[#1E2A78]">
                    <Save className="w-4 h-4 mr-2" />
                    Save Settings
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Account Settings */}
          <TabsContent value="account" className="space-y-6">
            <Card className="grayhub-card-glow">
              <CardHeader>
                <CardTitle>Account Management</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <h4 className="font-medium text-yellow-800 mb-2">Wallet Connected</h4>
                  <p className="text-sm text-yellow-700 mb-3">Your account is connected to wallet: 0x1234...5678</p>
                  <Button variant="outline" size="sm">
                    Disconnect Wallet
                  </Button>
                </div>

                <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                  <h4 className="font-medium text-red-800 mb-2">Danger Zone</h4>
                  <p className="text-sm text-red-700 mb-3">
                    Permanently delete your account and all associated data. This action cannot be undone.
                  </p>
                  <Button variant="destructive" size="sm">
                    Delete Account
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
