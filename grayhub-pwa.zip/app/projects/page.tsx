"use client"

import { useState } from "react"
import { Navbar } from "@/components/navbar"
import { ProjectCard } from "@/components/project-card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Search, Filter, Grid, List } from "lucide-react"

// Mock data for projects
const mockProjects = [
  {
    id: "1",
    title: "AI-Powered Smart Garden System",
    description:
      "An IoT-based automated garden management system using machine learning to optimize plant growth conditions.",
    author: "Sarah Chen",
    patentScore: 87,
    category: "IoT & Agriculture",
    likes: 124,
    views: 1250,
    price: "0.5",
    blockchain: "ethereum" as const,
  },
  {
    id: "2",
    title: "Blockchain-Based Voting Platform",
    description: "A secure, transparent voting system built on blockchain technology with zero-knowledge proofs.",
    author: "Alex Rodriguez",
    patentScore: 92,
    category: "Blockchain & Security",
    isPrivate: true,
    likes: 89,
    views: 890,
    price: "0.8",
    blockchain: "polygon" as const,
  },
  {
    id: "3",
    title: "Neural Network Music Composer",
    description: "An AI system that composes original music by learning from classical and contemporary pieces.",
    author: "Maya Patel",
    patentScore: 76,
    category: "AI & Music",
    likes: 156,
    views: 2100,
    price: "0.3",
    blockchain: "base" as const,
  },
  {
    id: "4",
    title: "Sustainable Energy Management App",
    description: "Mobile app for tracking and optimizing home energy consumption with renewable energy integration.",
    author: "David Kim",
    patentScore: 84,
    category: "Sustainability",
    likes: 98,
    views: 1450,
    price: "0.4",
    blockchain: "optimism" as const,
  },
  {
    id: "5",
    title: "AR-Based Learning Platform",
    description: "Augmented reality educational platform for immersive STEM learning experiences.",
    author: "Emma Johnson",
    patentScore: 79,
    category: "Education & AR",
    likes: 203,
    views: 3200,
    price: "0.6",
    blockchain: "arbitrum" as const,
  },
  {
    id: "6",
    title: "Quantum Computing Simulator",
    description: "Web-based quantum computing simulator for educational purposes with visual circuit builder.",
    author: "James Wilson",
    patentScore: 95,
    category: "Quantum Computing",
    likes: 67,
    views: 780,
    price: "1.2",
    blockchain: "ethereum" as const,
  },
]

const categories = [
  "All Categories",
  "AI & Machine Learning",
  "Blockchain & Security",
  "IoT & Agriculture",
  "Sustainability",
  "Education & AR",
  "Quantum Computing",
  "Biotechnology",
  "Robotics",
  "Fintech",
]

const blockchains = ["All Chains", "Ethereum", "Polygon", "Optimism", "Arbitrum", "Base"]

export default function ProjectsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("All Categories")
  const [selectedBlockchain, setSelectedBlockchain] = useState("All Chains")
  const [sortBy, setSortBy] = useState("newest")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [showFilters, setShowFilters] = useState(false)

  const filteredProjects = mockProjects.filter((project) => {
    const matchesSearch =
      project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.author.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesCategory =
      selectedCategory === "All Categories" ||
      project.category.includes(selectedCategory.replace("AI & Machine Learning", "AI"))

    const matchesBlockchain =
      selectedBlockchain === "All Chains" || project.blockchain.toLowerCase() === selectedBlockchain.toLowerCase()

    return matchesSearch && matchesCategory && matchesBlockchain
  })

  const sortedProjects = [...filteredProjects].sort((a, b) => {
    switch (sortBy) {
      case "newest":
        return Number.parseInt(b.id) - Number.parseInt(a.id)
      case "oldest":
        return Number.parseInt(a.id) - Number.parseInt(b.id)
      case "price-high":
        return Number.parseFloat(b.price || "0") - Number.parseFloat(a.price || "0")
      case "price-low":
        return Number.parseFloat(a.price || "0") - Number.parseFloat(b.price || "0")
      case "patent-score":
        return b.patentScore - a.patentScore
      case "popular":
        return b.likes - a.likes
      default:
        return 0
    }
  })

  return (
    <div className="min-h-screen grayhub-gradient">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Project Marketplace</h1>
          <p className="text-xl text-gray-600">Discover innovative student projects minted as NFTs</p>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-xl border border-gray-200 p-6 mb-8 grayhub-card-glow">
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input
                placeholder="Search projects, authors, or descriptions..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Filter Toggle */}
            <Button variant="outline" onClick={() => setShowFilters(!showFilters)} className="lg:hidden">
              <Filter className="w-4 h-4 mr-2" />
              Filters
            </Button>

            {/* View Mode Toggle */}
            <div className="flex border border-gray-200 rounded-lg overflow-hidden">
              <Button
                variant={viewMode === "grid" ? "default" : "ghost"}
                size="sm"
                onClick={() => setViewMode("grid")}
                className="rounded-none"
              >
                <Grid className="w-4 h-4" />
              </Button>
              <Button
                variant={viewMode === "list" ? "default" : "ghost"}
                size="sm"
                onClick={() => setViewMode("list")}
                className="rounded-none"
              >
                <List className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Filters */}
          <div className={`mt-6 grid grid-cols-1 md:grid-cols-3 gap-4 ${showFilters ? "block" : "hidden lg:grid"}`}>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger>
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={selectedBlockchain} onValueChange={setSelectedBlockchain}>
              <SelectTrigger>
                <SelectValue placeholder="Blockchain" />
              </SelectTrigger>
              <SelectContent>
                {blockchains.map((blockchain) => (
                  <SelectItem key={blockchain} value={blockchain}>
                    {blockchain}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger>
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest First</SelectItem>
                <SelectItem value="oldest">Oldest First</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="patent-score">Patent Score</SelectItem>
                <SelectItem value="popular">Most Popular</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Active Filters */}
        {(selectedCategory !== "All Categories" || selectedBlockchain !== "All Chains" || searchQuery) && (
          <div className="flex flex-wrap gap-2 mb-6">
            {searchQuery && (
              <Badge variant="secondary" className="bg-[#6C63FF]/10 text-[#6C63FF]">
                Search: {searchQuery}
                <button onClick={() => setSearchQuery("")} className="ml-2 text-[#6C63FF] hover:text-[#1E2A78]">
                  ×
                </button>
              </Badge>
            )}
            {selectedCategory !== "All Categories" && (
              <Badge variant="secondary" className="bg-[#6C63FF]/10 text-[#6C63FF]">
                {selectedCategory}
                <button
                  onClick={() => setSelectedCategory("All Categories")}
                  className="ml-2 text-[#6C63FF] hover:text-[#1E2A78]"
                >
                  ×
                </button>
              </Badge>
            )}
            {selectedBlockchain !== "All Chains" && (
              <Badge variant="secondary" className="bg-[#6C63FF]/10 text-[#6C63FF]">
                {selectedBlockchain}
                <button
                  onClick={() => setSelectedBlockchain("All Chains")}
                  className="ml-2 text-[#6C63FF] hover:text-[#1E2A78]"
                >
                  ×
                </button>
              </Badge>
            )}
          </div>
        )}

        {/* Results Count */}
        <div className="mb-6">
          <p className="text-gray-600">
            Showing {sortedProjects.length} of {mockProjects.length} projects
          </p>
        </div>

        {/* Projects Grid/List */}
        {sortedProjects.length > 0 ? (
          <div className={viewMode === "grid" ? "grid md:grid-cols-2 lg:grid-cols-3 gap-8" : "space-y-6"}>
            {sortedProjects.map((project) => (
              <ProjectCard key={project.id} {...project} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <div className="w-24 h-24 mx-auto bg-gray-100 rounded-full flex items-center justify-center mb-4">
              <Search className="w-12 h-12 text-gray-400" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No projects found</h3>
            <p className="text-gray-600 mb-6">Try adjusting your search criteria or browse all projects.</p>
            <Button
              onClick={() => {
                setSearchQuery("")
                setSelectedCategory("All Categories")
                setSelectedBlockchain("All Chains")
              }}
              className="bg-[#6C63FF] text-white hover:bg-[#1E2A78]"
            >
              Clear Filters
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
