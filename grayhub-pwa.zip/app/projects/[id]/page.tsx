"use client"

import { useState } from "react"
import { useParams } from "next/navigation"
import { Navbar } from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { AIPatentAnalyzer } from "@/components/ai-patent-analyzer"
import {
  Heart,
  Eye,
  Share2,
  Download,
  Lock,
  Unlock,
  ExternalLink,
  User,
  Calendar,
  Tag,
  FileText,
  Zap,
} from "lucide-react"

// Mock project data - in real app, this would come from API/blockchain
const mockProject = {
  id: "1",
  title: "AI-Powered Smart Garden System",
  description: `This innovative IoT-based automated garden management system leverages machine learning algorithms to optimize plant growth conditions. The system monitors soil moisture, temperature, humidity, and light levels in real-time, automatically adjusting irrigation, lighting, and climate control systems.

Key Features:
• Real-time environmental monitoring using IoT sensors
• Machine learning algorithms for predictive plant care
• Automated irrigation and climate control
• Mobile app for remote monitoring and control
• Data analytics dashboard for growth optimization
• Integration with weather APIs for predictive watering

The system has been tested in various environments and shows a 40% improvement in plant growth rates while reducing water consumption by 30%. This project represents a significant advancement in sustainable agriculture technology.`,
  author: "Sarah Chen",
  authorAddress: "0x1234...5678",
  authorAvatar: "",
  image: "",
  patentScore: 87,
  patentTrend: "up" as const,
  patentTrendValue: 5,
  category: "IoT & Agriculture",
  tags: ["IoT", "Machine Learning", "Agriculture", "Sustainability", "Automation"],
  isPrivate: false,
  likes: 124,
  views: 1250,
  price: "0.5",
  blockchain: "ethereum" as const,
  tokenId: "12345",
  contractAddress: "0xabcd...efgh",
  createdAt: "2024-01-15",
  files: [
    { name: "system_architecture.pdf", type: "document", size: "2.3 MB" },
    { name: "demo_video.mp4", type: "video", size: "15.7 MB" },
    { name: "source_code.zip", type: "code", size: "5.1 MB" },
    { name: "prototype_images.zip", type: "image", size: "8.9 MB" },
  ],
  collaborators: ["0x9876...5432", "0x5555...1111"],
  aiInsights: {
    patentability: "High potential for patent approval based on novelty and technical merit",
    marketPotential: "Strong commercial viability in the growing smart agriculture market",
    technicalComplexity: "Advanced integration of IoT, ML, and automation systems",
    improvementSuggestions: [
      "Consider adding computer vision for plant health assessment",
      "Implement blockchain for supply chain tracking",
      "Add support for multiple crop types",
    ],
  },
}

export default function ProjectDetailPage() {
  const params = useParams()
  const [liked, setLiked] = useState(false)
  const [likeCount, setLikeCount] = useState(mockProject.likes)

  const handleLike = () => {
    setLiked(!liked)
    setLikeCount((prev) => (liked ? prev - 1 : prev + 1))
  }

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: mockProject.title,
          text: mockProject.description.slice(0, 100) + "...",
          url: window.location.href,
        })
      } catch (error) {
        console.log("Error sharing:", error)
      }
    } else {
      // Fallback to clipboard
      navigator.clipboard.writeText(window.location.href)
      alert("Link copied to clipboard!")
    }
  }

  return (
    <div className="min-h-screen grayhub-gradient">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Project Header */}
            <Card className="grayhub-card-glow">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge className="bg-[#6C63FF]/10 text-[#6C63FF] border-[#6C63FF]">{mockProject.category}</Badge>
                      {mockProject.isPrivate ? (
                        <Badge variant="secondary" className="bg-red-100 text-red-800">
                          <Lock className="w-3 h-3 mr-1" />
                          Private
                        </Badge>
                      ) : (
                        <Badge variant="secondary" className="bg-green-100 text-green-800">
                          <Unlock className="w-3 h-3 mr-1" />
                          Public
                        </Badge>
                      )}
                    </div>
                    <h1 className="text-3xl font-bold text-gray-900 mb-4">{mockProject.title}</h1>

                    {/* Author Info */}
                    <div className="flex items-center mb-4">
                      <div className="w-10 h-10 bg-gradient-to-br from-[#6C63FF] to-[#1E2A78] rounded-full flex items-center justify-center mr-3">
                        <User className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{mockProject.author}</p>
                        <p className="text-sm text-gray-500 font-mono">{mockProject.authorAddress}</p>
                      </div>
                    </div>

                    {/* Stats */}
                    <div className="flex items-center space-x-6 text-sm text-gray-500 mb-4">
                      <div className="flex items-center">
                        <Eye className="w-4 h-4 mr-1" />
                        {mockProject.views} views
                      </div>
                      <div className="flex items-center">
                        <Heart className="w-4 h-4 mr-1" />
                        {likeCount} likes
                      </div>
                      <div className="flex items-center">
                        <Calendar className="w-4 h-4 mr-1" />
                        {new Date(mockProject.createdAt).toLocaleDateString()}
                      </div>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm" onClick={handleLike}>
                      <Heart className={`w-4 h-4 mr-2 ${liked ? "fill-red-500 text-red-500" : ""}`} />
                      {liked ? "Liked" : "Like"}
                    </Button>
                    <Button variant="outline" size="sm" onClick={handleShare}>
                      <Share2 className="w-4 h-4 mr-2" />
                      Share
                    </Button>
                  </div>
                </div>

                {/* Project Image */}
                <div className="aspect-video bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg mb-6 flex items-center justify-center">
                  <div className="w-24 h-24 bg-gradient-to-br from-[#6C63FF] to-[#1E2A78] rounded-full flex items-center justify-center">
                    <Zap className="w-12 h-12 text-white" />
                  </div>
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {mockProject.tags.map((tag) => (
                    <Badge key={tag} variant="outline" className="text-gray-600">
                      <Tag className="w-3 h-3 mr-1" />
                      {tag}
                    </Badge>
                  ))}
                </div>

                {/* Description */}
                <div className="prose max-w-none">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Project Description</h3>
                  <div className="text-gray-700 whitespace-pre-line leading-relaxed">{mockProject.description}</div>
                </div>
              </CardContent>
            </Card>

            {/* Patent Score & AI Insights */}
            <AIPatentAnalyzer
              projectId={mockProject.id}
              projectTitle={mockProject.title}
              projectDescription={mockProject.description}
            />

            {/* Project Files */}
            <Card className="grayhub-card-glow">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FileText className="w-5 h-5 mr-2 text-[#6C63FF]" />
                  Project Files
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {mockProject.files.map((file, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center">
                        <FileText className="w-5 h-5 text-gray-500 mr-3" />
                        <div>
                          <p className="font-medium text-gray-900">{file.name}</p>
                          <p className="text-sm text-gray-500">{file.size}</p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">
                        <Download className="w-4 h-4 mr-2" />
                        Download
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Purchase Card */}
            <Card className="grayhub-card-glow">
              <CardHeader>
                <CardTitle>Purchase NFT</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <div className="text-3xl font-bold text-gray-900">{mockProject.price} ETH</div>
                  <div className="text-sm text-gray-500">≈ $1,250 USD</div>
                </div>

                <Button className="w-full bg-black text-white hover:bg-gray-800">
                  <Zap className="w-4 h-4 mr-2" />
                  Buy Now
                </Button>

                <Button variant="outline" className="w-full bg-transparent">
                  Make Offer
                </Button>

                <div className="pt-4 border-t border-gray-200">
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Blockchain:</span>
                      <span className="font-medium capitalize">{mockProject.blockchain}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Token ID:</span>
                      <span className="font-mono">{mockProject.tokenId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Contract:</span>
                      <span className="font-mono text-xs">{mockProject.contractAddress}</span>
                    </div>
                  </div>
                </div>

                <Button variant="outline" className="w-full bg-transparent" size="sm">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  View on Etherscan
                </Button>
              </CardContent>
            </Card>

            {/* Collaborators */}
            {mockProject.collaborators.length > 0 && (
              <Card className="grayhub-card-glow">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <User className="w-5 h-5 mr-2 text-[#6C63FF]" />
                    Collaborators
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {mockProject.collaborators.map((collaborator, index) => (
                      <div key={index} className="flex items-center">
                        <div className="w-8 h-8 bg-gradient-to-br from-[#6C63FF] to-[#1E2A78] rounded-full flex items-center justify-center mr-3">
                          <User className="w-4 h-4 text-white" />
                        </div>
                        <span className="font-mono text-sm">{collaborator}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
