"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Navbar } from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Upload, X, FileText, ImageIcon, Video, Code, Plus, Lock, Users, Zap } from "lucide-react"
import { useMintProject } from "@/lib/contracts"
import { useAccount, useChainId } from "wagmi"
import { notificationService } from "@/lib/notifications"

const categories = [
  "AI & Machine Learning",
  "Blockchain & Security",
  "IoT & Agriculture",
  "Sustainability",
  "Education & AR",
  "Quantum Computing",
  "Biotechnology",
  "Robotics",
  "Fintech",
  "Healthcare",
  "Gaming",
  "Other",
]

const fileTypeIcons = {
  image: ImageIcon,
  video: Video,
  document: FileText,
  code: Code,
  other: FileText,
}

export default function SubmitProjectPage() {
  const router = useRouter()
  const { address } = useAccount()
  const chainId = useChainId()
  const { mintProject, isPending, isSuccess, error } = useMintProject()

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "",
    tags: [] as string[],
    isPrivate: false,
    collaborators: [] as string[],
  })

  const [files, setFiles] = useState<File[]>([])
  const [newTag, setNewTag] = useState("")
  const [newCollaborator, setNewCollaborator] = useState("")
  const [dragActive, setDragActive] = useState(false)

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleFileUpload = (uploadedFiles: FileList | null) => {
    if (!uploadedFiles) return

    const newFiles = Array.from(uploadedFiles).filter((file) => {
      // Limit file size to 50MB
      if (file.size > 50 * 1024 * 1024) {
        alert(`File ${file.name} is too large. Maximum size is 50MB.`)
        return false
      }
      return true
    })

    setFiles((prev) => [...prev, ...newFiles].slice(0, 10)) // Max 10 files
  }

  const removeFile = (index: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== index))
  }

  const addTag = () => {
    if (newTag.trim() && !formData.tags.includes(newTag.trim())) {
      setFormData((prev) => ({
        ...prev,
        tags: [...prev.tags, newTag.trim()],
      }))
      setNewTag("")
    }
  }

  const removeTag = (tag: string) => {
    setFormData((prev) => ({
      ...prev,
      tags: prev.tags.filter((t) => t !== tag),
    }))
  }

  const addCollaborator = () => {
    if (newCollaborator.trim() && !formData.collaborators.includes(newCollaborator.trim())) {
      setFormData((prev) => ({
        ...prev,
        collaborators: [...prev.collaborators, newCollaborator.trim()],
      }))
      setNewCollaborator("")
    }
  }

  const removeCollaborator = (collaborator: string) => {
    setFormData((prev) => ({
      ...prev,
      collaborators: prev.collaborators.filter((c) => c !== collaborator),
    }))
  }

  const getFileType = (file: File): keyof typeof fileTypeIcons => {
    if (file.type.startsWith("image/")) return "image"
    if (file.type.startsWith("video/")) return "video"
    if (file.type.includes("text/") || file.type.includes("document")) return "document"
    if (file.type.includes("code") || file.name.includes(".js") || file.name.includes(".py")) return "code"
    return "other"
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!address) {
      alert("Please connect your wallet first")
      return
    }

    if (!formData.title || !formData.description || !formData.category || files.length === 0) {
      alert("Please fill in all required fields and upload at least one file")
      return
    }

    try {
      await mintProject(
        {
          title: formData.title,
          description: formData.description,
          category: formData.category,
          author: address,
          files,
          isPrivate: formData.isPrivate,
          collaborators: formData.collaborators,
          tags: formData.tags,
        },
        chainId,
      )

      // Show success notification
      await notificationService.triggerNFTMintNotification(formData.title)

      // Redirect to dashboard or project page
      router.push("/dashboard")
    } catch (error) {
      console.error("Error submitting project:", error)
      alert("Failed to submit project. Please try again.")
    }
  }

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files)
    }
  }

  return (
    <div className="min-h-screen grayhub-gradient">
      <Navbar />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Submit Your Project</h1>
          <p className="text-xl text-gray-600">Transform your innovation into an NFT and join the GrayHub ecosystem</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Basic Information */}
          <Card className="grayhub-card-glow">
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="w-5 h-5 mr-2 text-[#6C63FF]" />
                Project Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label htmlFor="title">Project Title *</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => handleInputChange("title", e.target.value)}
                  placeholder="Enter your project title"
                  className="mt-1"
                  required
                />
              </div>

              <div>
                <Label htmlFor="description">Description *</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => handleInputChange("description", e.target.value)}
                  placeholder="Describe your project, its purpose, and key features"
                  className="mt-1 min-h-[120px]"
                  required
                />
              </div>

              <div>
                <Label htmlFor="category">Category *</Label>
                <Select value={formData.category} onValueChange={(value) => handleInputChange("category", value)}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Tags */}
              <div>
                <Label>Tags</Label>
                <div className="mt-1 space-y-2">
                  <div className="flex gap-2">
                    <Input
                      value={newTag}
                      onChange={(e) => setNewTag(e.target.value)}
                      placeholder="Add a tag"
                      onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addTag())}
                    />
                    <Button type="button" onClick={addTag} size="sm">
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                  {formData.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {formData.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="bg-[#6C63FF]/10 text-[#6C63FF]">
                          {tag}
                          <button
                            type="button"
                            onClick={() => removeTag(tag)}
                            className="ml-2 text-[#6C63FF] hover:text-[#1E2A78]"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* File Upload */}
          <Card className="grayhub-card-glow">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Upload className="w-5 h-5 mr-2 text-[#6C63FF]" />
                Project Files *
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div
                className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                  dragActive ? "border-[#6C63FF] bg-[#6C63FF]/5" : "border-gray-300 hover:border-[#6C63FF]"
                }`}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              >
                <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-lg font-medium text-gray-900 mb-2">Drop files here or click to upload</p>
                <p className="text-gray-600 mb-4">
                  Support for images, videos, documents, and code files (Max 50MB each, 10 files total)
                </p>
                <input
                  type="file"
                  multiple
                  onChange={(e) => handleFileUpload(e.target.files)}
                  className="hidden"
                  id="file-upload"
                  accept="image/*,video/*,.pdf,.doc,.docx,.txt,.md,.js,.py,.html,.css"
                />
                <Button type="button" asChild className="bg-[#6C63FF] text-white hover:bg-[#1E2A78]">
                  <label htmlFor="file-upload" className="cursor-pointer">
                    Choose Files
                  </label>
                </Button>
              </div>

              {/* File List */}
              {files.length > 0 && (
                <div className="mt-6 space-y-2">
                  <h4 className="font-medium text-gray-900">Uploaded Files ({files.length}/10)</h4>
                  {files.map((file, index) => {
                    const FileIcon = fileTypeIcons[getFileType(file)]
                    return (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center">
                          <FileIcon className="w-5 h-5 text-gray-500 mr-3" />
                          <div>
                            <p className="font-medium text-gray-900">{file.name}</p>
                            <p className="text-sm text-gray-500">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                          </div>
                        </div>
                        <Button type="button" variant="ghost" size="sm" onClick={() => removeFile(index)}>
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    )
                  })}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Privacy & Collaboration */}
          <Card className="grayhub-card-glow">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Lock className="w-5 h-5 mr-2 text-[#6C63FF]" />
                Privacy & Collaboration
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="private"
                  checked={formData.isPrivate}
                  onCheckedChange={(checked) => handleInputChange("isPrivate", checked as boolean)}
                />
                <Label htmlFor="private" className="flex items-center">
                  <Lock className="w-4 h-4 mr-2" />
                  Make this project private (requires NDA for access)
                </Label>
              </div>

              {/* Collaborators */}
              <div>
                <Label className="flex items-center">
                  <Users className="w-4 h-4 mr-2" />
                  Collaborators (Wallet Addresses)
                </Label>
                <div className="mt-1 space-y-2">
                  <div className="flex gap-2">
                    <Input
                      value={newCollaborator}
                      onChange={(e) => setNewCollaborator(e.target.value)}
                      placeholder="0x..."
                      onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addCollaborator())}
                    />
                    <Button type="button" onClick={addCollaborator} size="sm">
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                  {formData.collaborators.length > 0 && (
                    <div className="space-y-2">
                      {formData.collaborators.map((collaborator) => (
                        <div key={collaborator} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                          <span className="font-mono text-sm">{collaborator}</span>
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => removeCollaborator(collaborator)}
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Submit Button */}
          <div className="flex justify-end space-x-4">
            <Button type="button" variant="outline" onClick={() => router.back()}>
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isPending || !address}
              className="bg-black text-white hover:bg-gray-800 px-8"
            >
              {isPending ? (
                <>
                  <Zap className="w-4 h-4 mr-2 animate-spin" />
                  Minting NFT...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 mr-2" />
                  Submit & Mint NFT
                </>
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
