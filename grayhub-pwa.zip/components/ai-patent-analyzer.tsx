"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PatentScoreMeter } from "./patent-score-meter"
import { Brain, Zap, CheckCircle, TrendingUp, Search, Shield, Lightbulb, Target } from "lucide-react"

interface AIPatentAnalyzerProps {
  projectId: string
  projectTitle: string
  projectDescription: string
  files?: File[]
}

// Mock AI analysis data - in real app, this would come from AI API
const mockAnalysis = {
  overallScore: 87,
  noveltyScore: 92,
  technicalMeritScore: 85,
  marketPotentialScore: 83,
  patentabilityScore: 89,

  similarPatents: [
    {
      id: "US10123456",
      title: "Smart Agricultural Monitoring System",
      similarity: 68,
      status: "granted",
      year: 2019,
    },
    {
      id: "US10789012",
      title: "IoT-Based Plant Care Device",
      similarity: 45,
      status: "pending",
      year: 2022,
    },
    {
      id: "EP3456789",
      title: "Automated Garden Management",
      similarity: 52,
      status: "granted",
      year: 2020,
    },
  ],

  noveltyHeatmap: [
    { section: "IoT Sensor Integration", novelty: 95, description: "Unique multi-sensor fusion approach" },
    { section: "ML Algorithm", novelty: 88, description: "Novel predictive watering algorithm" },
    { section: "Mobile Interface", novelty: 45, description: "Standard mobile app implementation" },
    { section: "Hardware Design", novelty: 72, description: "Improved weatherproof housing" },
    { section: "Data Analytics", novelty: 91, description: "Advanced growth optimization metrics" },
  ],

  plagiarismCheck: {
    overallScore: 96,
    sources: [
      { source: "Academic Papers", similarity: 12, status: "safe" },
      { source: "Existing Patents", similarity: 8, status: "safe" },
      { source: "Open Source Projects", similarity: 15, status: "safe" },
      { source: "Commercial Products", similarity: 6, status: "safe" },
    ],
  },

  improvements: [
    {
      category: "Technical Enhancement",
      suggestion: "Consider adding computer vision for plant health assessment",
      impact: "high",
      patentStrength: "+8 points",
    },
    {
      category: "Market Differentiation",
      suggestion: "Implement blockchain for supply chain tracking",
      impact: "medium",
      patentStrength: "+5 points",
    },
    {
      category: "Innovation Scope",
      suggestion: "Add support for multiple crop types and growth stages",
      impact: "high",
      patentStrength: "+7 points",
    },
    {
      category: "Technical Depth",
      suggestion: "Integrate weather prediction APIs for proactive care",
      impact: "medium",
      patentStrength: "+4 points",
    },
  ],

  riskAssessment: {
    level: "low",
    factors: [
      { risk: "Prior Art Conflict", level: "low", description: "No direct conflicts found" },
      { risk: "Obviousness", level: "low", description: "Novel combination of technologies" },
      { risk: "Market Saturation", level: "medium", description: "Growing but competitive market" },
      { risk: "Technical Feasibility", level: "low", description: "Proven technologies used" },
    ],
  },
}

export function AIPatentAnalyzer({ projectId, projectTitle, projectDescription, files }: AIPatentAnalyzerProps) {
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisComplete, setAnalysisComplete] = useState(true) // Set to true for demo
  const [activeTab, setActiveTab] = useState("overview")

  const runAnalysis = async () => {
    setIsAnalyzing(true)
    // Simulate AI analysis
    await new Promise((resolve) => setTimeout(resolve, 3000))
    setIsAnalyzing(false)
    setAnalysisComplete(true)
  }

  if (!analysisComplete) {
    return (
      <Card className="grayhub-card-glow">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Brain className="w-5 h-5 mr-2 text-[#6C63FF]" />
            AI Patent Analysis 2.0
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center py-8">
          {!isAnalyzing ? (
            <div>
              <Brain className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Ready for AI Analysis</h3>
              <p className="text-gray-600 mb-6">
                Get comprehensive patent scoring, novelty analysis, and improvement suggestions
              </p>
              <Button onClick={runAnalysis} className="bg-[#6C63FF] text-white hover:bg-[#1E2A78]">
                <Zap className="w-4 h-4 mr-2" />
                Start AI Analysis
              </Button>
            </div>
          ) : (
            <div>
              <div className="w-16 h-16 border-4 border-[#6C63FF] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Analyzing Your Project</h3>
              <p className="text-gray-600 mb-4">
                Our AI is examining your project for novelty, patent potential, and market viability...
              </p>
              <div className="max-w-md mx-auto">
                <Progress value={75} className="mb-2" />
                <p className="text-sm text-gray-500">Checking against 2.3M patents...</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Analysis Overview */}
      <Card className="grayhub-card-glow">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Brain className="w-5 h-5 mr-2 text-[#6C63FF]" />
            AI Patent Analysis 2.0
            <Badge className="ml-2 bg-green-100 text-green-800">Complete</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <PatentScoreMeter score={mockAnalysis.overallScore} size="lg" />
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Novelty Score</span>
                <span className="font-semibold text-[#6C63FF]">{mockAnalysis.noveltyScore}/100</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Technical Merit</span>
                <span className="font-semibold text-gray-900">{mockAnalysis.technicalMeritScore}/100</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Market Potential</span>
                <span className="font-semibold text-gray-900">{mockAnalysis.marketPotentialScore}/100</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Patentability</span>
                <span className="font-semibold text-green-600">{mockAnalysis.patentabilityScore}/100</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Detailed Analysis Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="novelty">Novelty Map</TabsTrigger>
          <TabsTrigger value="similar">Similar Patents</TabsTrigger>
          <TabsTrigger value="plagiarism">Plagiarism Check</TabsTrigger>
          <TabsTrigger value="improvements">Suggestions</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="grayhub-card-glow">
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <Shield className="w-5 h-5 mr-2 text-green-600" />
                  Risk Assessment
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center mb-4">
                  <Badge
                    className={`${mockAnalysis.riskAssessment.level === "low" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"}`}
                  >
                    {mockAnalysis.riskAssessment.level.toUpperCase()} RISK
                  </Badge>
                </div>
                <div className="space-y-3">
                  {mockAnalysis.riskAssessment.factors.map((factor, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-gray-900 text-sm">{factor.risk}</p>
                        <p className="text-xs text-gray-600">{factor.description}</p>
                      </div>
                      <Badge
                        variant="outline"
                        className={
                          factor.level === "low"
                            ? "text-green-600 border-green-600"
                            : factor.level === "medium"
                              ? "text-yellow-600 border-yellow-600"
                              : "text-red-600 border-red-600"
                        }
                      >
                        {factor.level}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="grayhub-card-glow">
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <Target className="w-5 h-5 mr-2 text-[#6C63FF]" />
                  Key Strengths
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-2 mt-0.5" />
                    <div>
                      <p className="font-medium text-gray-900 text-sm">Novel ML Integration</p>
                      <p className="text-xs text-gray-600">Unique predictive algorithms for plant care</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-2 mt-0.5" />
                    <div>
                      <p className="font-medium text-gray-900 text-sm">Strong Technical Merit</p>
                      <p className="text-xs text-gray-600">Well-documented implementation approach</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-2 mt-0.5" />
                    <div>
                      <p className="font-medium text-gray-900 text-sm">Market Readiness</p>
                      <p className="text-xs text-gray-600">Clear commercial application path</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Novelty Heatmap Tab */}
        <TabsContent value="novelty" className="space-y-6">
          <Card className="grayhub-card-glow">
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUp className="w-5 h-5 mr-2 text-[#6C63FF]" />
                Novelty Heatmap
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockAnalysis.noveltyHeatmap.map((section, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium text-gray-900">{section.section}</h4>
                      <Badge
                        className={
                          section.novelty >= 80
                            ? "bg-green-100 text-green-800"
                            : section.novelty >= 60
                              ? "bg-yellow-100 text-yellow-800"
                              : "bg-red-100 text-red-800"
                        }
                      >
                        {section.novelty}% Novel
                      </Badge>
                    </div>
                    <Progress value={section.novelty} className="h-2" />
                    <p className="text-sm text-gray-600">{section.description}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Similar Patents Tab */}
        <TabsContent value="similar" className="space-y-6">
          <Card className="grayhub-card-glow">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Search className="w-5 h-5 mr-2 text-[#6C63FF]" />
                Similar Patents Found
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockAnalysis.similarPatents.map((patent, index) => (
                  <div key={index} className="p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h4 className="font-medium text-gray-900">{patent.title}</h4>
                        <p className="text-sm text-gray-600 font-mono">
                          {patent.id} • {patent.year}
                        </p>
                      </div>
                      <div className="text-right">
                        <Badge
                          className={
                            patent.similarity < 30
                              ? "bg-green-100 text-green-800"
                              : patent.similarity < 60
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-red-100 text-red-800"
                          }
                        >
                          {patent.similarity}% Similar
                        </Badge>
                        <p className="text-xs text-gray-500 mt-1 capitalize">{patent.status}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Plagiarism Check Tab */}
        <TabsContent value="plagiarism" className="space-y-6">
          <Card className="grayhub-card-glow">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="w-5 h-5 mr-2 text-green-600" />
                Plagiarism Detection
                <Badge className="ml-2 bg-green-100 text-green-800">
                  {mockAnalysis.plagiarismCheck.overallScore}% Original
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockAnalysis.plagiarismCheck.sources.map((source, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <h4 className="font-medium text-gray-900">{source.source}</h4>
                      <p className="text-sm text-gray-600">{source.similarity}% similarity detected</p>
                    </div>
                    <div className="flex items-center">
                      <CheckCircle className="w-5 h-5 text-green-500 mr-2" />
                      <Badge className="bg-green-100 text-green-800">Safe</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Improvements Tab */}
        <TabsContent value="improvements" className="space-y-6">
          <Card className="grayhub-card-glow">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Lightbulb className="w-5 h-5 mr-2 text-[#6C63FF]" />
                AI Improvement Suggestions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockAnalysis.improvements.map((improvement, index) => (
                  <div key={index} className="p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <div className="flex items-center mb-2">
                          <Badge variant="outline" className="text-[#6C63FF] border-[#6C63FF] mr-2">
                            {improvement.category}
                          </Badge>
                          <Badge
                            className={
                              improvement.impact === "high"
                                ? "bg-red-100 text-red-800"
                                : improvement.impact === "medium"
                                  ? "bg-yellow-100 text-yellow-800"
                                  : "bg-green-100 text-green-800"
                            }
                          >
                            {improvement.impact} impact
                          </Badge>
                        </div>
                        <p className="text-gray-900 mb-1">{improvement.suggestion}</p>
                        <p className="text-sm text-green-600 font-medium">
                          Potential patent strength: {improvement.patentStrength}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
