"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { X, Send, Paperclip, Smile } from "lucide-react"

interface ChatInterfaceProps {
  collaborationId: string
  onClose: () => void
}

const mockMessages = [
  {
    id: "1",
    sender: "Alex Rodriguez",
    message: "Hey team! I've finished the smart contract architecture. Ready for review.",
    timestamp: "10:30 AM",
    isCurrentUser: false,
  },
  {
    id: "2",
    sender: "You",
    message: "Great work! I'll take a look at it this afternoon.",
    timestamp: "10:32 AM",
    isCurrentUser: true,
  },
  {
    id: "3",
    sender: "Maya Patel",
    message: "I'm making good progress on the ZK-SNARK implementation. Should have a prototype by tomorrow.",
    timestamp: "11:15 AM",
    isCurrentUser: false,
  },
  {
    id: "4",
    sender: "Sarah Chen",
    message: "The UI mockups are ready! Check them out in the shared folder.",
    timestamp: "2:45 PM",
    isCurrentUser: false,
  },
]

export function ChatInterface({ collaborationId, onClose }: ChatInterfaceProps) {
  const [message, setMessage] = useState("")
  const [messages, setMessages] = useState(mockMessages)

  const handleSendMessage = () => {
    if (message.trim()) {
      const newMessage = {
        id: Date.now().toString(),
        sender: "You",
        message: message.trim(),
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        isCurrentUser: true,
      }
      setMessages([...messages, newMessage])
      setMessage("")
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-2xl h-[600px] flex flex-col">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <CardTitle>Team Chat</CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </CardHeader>

        <CardContent className="flex-1 flex flex-col p-0">
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((msg) => (
              <div key={msg.id} className={`flex ${msg.isCurrentUser ? "justify-end" : "justify-start"}`}>
                <div
                  className={`flex items-start max-w-xs lg:max-w-md ${msg.isCurrentUser ? "flex-row-reverse" : "flex-row"}`}
                >
                  <Avatar className="w-8 h-8">
                    <AvatarFallback className="bg-gradient-to-br from-[#6C63FF] to-[#1E2A78] text-white text-xs">
                      {msg.sender
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className={`mx-2 ${msg.isCurrentUser ? "text-right" : "text-left"}`}>
                    <div
                      className={`rounded-lg px-3 py-2 ${
                        msg.isCurrentUser ? "bg-[#6C63FF] text-white" : "bg-gray-100 text-gray-900"
                      }`}
                    >
                      <p className="text-sm">{msg.message}</p>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {msg.isCurrentUser ? msg.timestamp : `${msg.sender} • ${msg.timestamp}`}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Message Input */}
          <div className="border-t border-gray-200 p-4">
            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="sm">
                <Paperclip className="w-4 h-4" />
              </Button>
              <Input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type a message..."
                className="flex-1"
              />
              <Button variant="ghost" size="sm">
                <Smile className="w-4 h-4" />
              </Button>
              <Button
                onClick={handleSendMessage}
                disabled={!message.trim()}
                className="bg-[#6C63FF] text-white hover:bg-[#1E2A78]"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
