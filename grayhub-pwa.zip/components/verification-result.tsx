"use client"

import { motion } from "framer-motion"
import { CheckCircle, XCircle, AlertTriangle, FileText, Calendar, Hash, Shield } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ConfidenceMeter } from "@/components/confidence-meter"

interface VerificationResultProps {
  result: {
    status: "AUTHENTIC" | "FAKE" | "SUSPICIOUS"
    confidence: number
    fileName: string
    fileType: string
    timestamp: string
    details: {
      signatures: { verified: boolean; count: number }
      logos: { verified: boolean; count: number }
      seals: { verified: boolean; count: number }
      qrCodes: { verified: boolean; count: number }
      blockchainHash?: string
      issuer?: string
      issueDate?: string
      expiryDate?: string
    }
  }
}

export function VerificationResult({ result }: VerificationResultProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "AUTHENTIC":
        return <CheckCircle className="h-6 w-6 text-emerald-500" />
      case "FAKE":
        return <XCircle className="h-6 w-6 text-red-500" />
      case "SUSPICIOUS":
        return <AlertTriangle className="h-6 w-6 text-yellow-500" />
      default:
        return <AlertTriangle className="h-6 w-6 text-slate-500" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "AUTHENTIC":
        return "bg-emerald-100 text-emerald-800 border-emerald-200"
      case "FAKE":
        return "bg-red-100 text-red-800 border-red-200"
      case "SUSPICIOUS":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      default:
        return "bg-slate-100 text-slate-800 border-slate-200"
    }
  }

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      {/* Main Result Card */}
      <Card className="border-2 bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {getStatusIcon(result.status)}
              <div>
                <CardTitle className="text-xl">Verification Complete</CardTitle>
                <CardDescription className="flex items-center gap-2 mt-1">
                  <FileText className="h-4 w-4" />
                  {result.fileName}
                </CardDescription>
              </div>
            </div>
            <Badge className={getStatusColor(result.status)}>{result.status}</Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex flex-col lg:flex-row gap-8 items-center">
            {/* Confidence Meter */}
            <div className="flex-shrink-0">
              <ConfidenceMeter confidence={result.confidence} size="lg" />
            </div>

            {/* Verification Details */}
            <div className="flex-1 space-y-4 w-full">
              <h3 className="font-semibold text-lg text-slate-800">Verification Details</h3>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                    <span className="text-sm font-medium text-slate-600">Signatures</span>
                    <div className="flex items-center gap-2">
                      {result.details.signatures.verified ? (
                        <CheckCircle className="h-4 w-4 text-emerald-500" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-500" />
                      )}
                      <span className="text-sm font-medium">{result.details.signatures.count} found</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                    <span className="text-sm font-medium text-slate-600">Logos</span>
                    <div className="flex items-center gap-2">
                      {result.details.logos.verified ? (
                        <CheckCircle className="h-4 w-4 text-emerald-500" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-500" />
                      )}
                      <span className="text-sm font-medium">{result.details.logos.count} found</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                    <span className="text-sm font-medium text-slate-600">Seals</span>
                    <div className="flex items-center gap-2">
                      {result.details.seals.verified ? (
                        <CheckCircle className="h-4 w-4 text-emerald-500" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-500" />
                      )}
                      <span className="text-sm font-medium">{result.details.seals.count} found</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                    <span className="text-sm font-medium text-slate-600">QR Codes</span>
                    <div className="flex items-center gap-2">
                      {result.details.qrCodes.verified ? (
                        <CheckCircle className="h-4 w-4 text-emerald-500" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-500" />
                      )}
                      <span className="text-sm font-medium">{result.details.qrCodes.count} found</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Additional Information */}
          {(result.details.issuer || result.details.issueDate || result.details.blockchainHash) && (
            <div className="border-t pt-4 space-y-3">
              <h4 className="font-medium text-slate-800">Additional Information</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {result.details.issuer && (
                  <div className="flex items-center gap-2 p-2 bg-blue-50 rounded-lg">
                    <Shield className="h-4 w-4 text-blue-600" />
                    <div>
                      <div className="text-xs text-blue-600 font-medium">Issuer</div>
                      <div className="text-sm text-slate-700">{result.details.issuer}</div>
                    </div>
                  </div>
                )}

                {result.details.issueDate && (
                  <div className="flex items-center gap-2 p-2 bg-violet-50 rounded-lg">
                    <Calendar className="h-4 w-4 text-violet-600" />
                    <div>
                      <div className="text-xs text-violet-600 font-medium">Issue Date</div>
                      <div className="text-sm text-slate-700">{result.details.issueDate}</div>
                    </div>
                  </div>
                )}

                {result.details.blockchainHash && (
                  <div className="flex items-center gap-2 p-2 bg-emerald-50 rounded-lg">
                    <Hash className="h-4 w-4 text-emerald-600" />
                    <div>
                      <div className="text-xs text-emerald-600 font-medium">Blockchain Hash</div>
                      <div className="text-sm text-slate-700 font-mono truncate">
                        {result.details.blockchainHash.slice(0, 12)}...
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t">
            <Button variant="outline" className="flex-1 bg-transparent">
              Download Report
            </Button>
            <Button variant="outline" className="flex-1 bg-transparent">
              Share Result
            </Button>
            <Button className="flex-1 bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-700 hover:to-blue-700">
              Verify Another
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
