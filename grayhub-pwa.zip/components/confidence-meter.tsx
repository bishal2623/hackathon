"use client"

import { motion } from "framer-motion"
import { cn } from "@/lib/utils"

interface ConfidenceMeterProps {
  confidence: number
  size?: "sm" | "md" | "lg"
  showLabel?: boolean
  className?: string
}

export function ConfidenceMeter({ confidence, size = "md", showLabel = true, className }: ConfidenceMeterProps) {
  const radius = size === "sm" ? 40 : size === "md" ? 60 : 80
  const strokeWidth = size === "sm" ? 6 : size === "md" ? 8 : 10
  const normalizedRadius = radius - strokeWidth * 2
  const circumference = normalizedRadius * 2 * Math.PI
  const strokeDasharray = `${circumference} ${circumference}`
  const strokeDashoffset = circumference - (confidence / 100) * circumference

  // Color based on confidence level
  const getColor = (confidence: number) => {
    if (confidence >= 80) return "text-emerald-500"
    if (confidence >= 60) return "text-yellow-500"
    return "text-red-500"
  }

  const getGradientId = (confidence: number) => {
    if (confidence >= 80) return "emerald-gradient"
    if (confidence >= 60) return "yellow-gradient"
    return "red-gradient"
  }

  const getStatus = (confidence: number) => {
    if (confidence >= 80) return "AUTHENTIC"
    if (confidence >= 60) return "SUSPICIOUS"
    return "FAKE"
  }

  return (
    <div className={cn("flex flex-col items-center space-y-2", className)}>
      <div className="relative">
        <svg height={radius * 2} width={radius * 2} className="transform -rotate-90">
          <defs>
            <linearGradient id="emerald-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#10b981" />
              <stop offset="100%" stopColor="#059669" />
            </linearGradient>
            <linearGradient id="yellow-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#f59e0b" />
              <stop offset="100%" stopColor="#d97706" />
            </linearGradient>
            <linearGradient id="red-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#ef4444" />
              <stop offset="100%" stopColor="#dc2626" />
            </linearGradient>
          </defs>

          {/* Background circle */}
          <circle
            stroke="currentColor"
            fill="transparent"
            strokeWidth={strokeWidth}
            strokeDasharray={strokeDasharray}
            style={{ strokeDashoffset: 0 }}
            r={normalizedRadius}
            cx={radius}
            cy={radius}
            className="text-slate-200"
          />

          {/* Progress circle */}
          <motion.circle
            stroke={`url(#${getGradientId(confidence)})`}
            fill="transparent"
            strokeWidth={strokeWidth}
            strokeDasharray={strokeDasharray}
            strokeLinecap="round"
            r={normalizedRadius}
            cx={radius}
            cy={radius}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
          />
        </svg>

        {/* Center content */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.span
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5, duration: 0.5 }}
            className={cn(
              "font-bold",
              size === "sm" ? "text-lg" : size === "md" ? "text-2xl" : "text-3xl",
              getColor(confidence),
            )}
          >
            {confidence}%
          </motion.span>
          {size !== "sm" && (
            <motion.span
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.7, duration: 0.5 }}
              className={cn("text-xs font-medium text-slate-600 mt-1", size === "lg" && "text-sm")}
            >
              CONFIDENCE
            </motion.span>
          )}
        </div>
      </div>

      {showLabel && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.5 }}
          className="text-center"
        >
          <div className={cn("font-bold", size === "sm" ? "text-sm" : "text-lg", getColor(confidence))}>
            {getStatus(confidence)}
          </div>
          <div className="text-xs text-slate-500 mt-1">Verification Status</div>
        </motion.div>
      )}
    </div>
  )
}
