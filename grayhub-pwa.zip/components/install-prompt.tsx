"use client"

import { useState, useEffect } from "react"
import { Download, X } from "lucide-react"
import { Button } from "@/components/ui/button"

interface BeforeInstallPromptEvent extends Event {
  readonly platforms: string[]
  readonly userChoice: Promise<{
    outcome: "accepted" | "dismissed"
    platform: string
  }>
  prompt(): Promise<void>
}

export function InstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null)
  const [showInstallPrompt, setShowInstallPrompt] = useState(false)

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault()
      setDeferredPrompt(e as BeforeInstallPromptEvent)
      setShowInstallPrompt(true)
    }

    window.addEventListener("beforeinstallprompt", handler)

    return () => {
      window.removeEventListener("beforeinstallprompt", handler)
    }
  }, [])

  const handleInstallClick = async () => {
    if (!deferredPrompt) return

    deferredPrompt.prompt()
    const { outcome } = await deferredPrompt.userChoice

    if (outcome === "accepted") {
      setDeferredPrompt(null)
      setShowInstallPrompt(false)
    }
  }

  const handleDismiss = () => {
    setShowInstallPrompt(false)
    setDeferredPrompt(null)
  }

  if (!showInstallPrompt) return null

  return (
    <div className="fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:max-w-sm z-50">
      <div className="bg-white border border-gray-200 rounded-lg shadow-lg p-4 grayhub-card-glow">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h3 className="font-semibold text-gray-900 mb-1">Install GrayHub</h3>
            <p className="text-sm text-gray-600 mb-3">
              Install our app for a better experience with offline access and notifications.
            </p>
            <div className="flex gap-2">
              <Button onClick={handleInstallClick} size="sm" className="bg-[#6C63FF] text-white hover:bg-[#1E2A78]">
                <Download className="w-4 h-4 mr-1" />
                Install
              </Button>
              <Button onClick={handleDismiss} variant="outline" size="sm">
                Later
              </Button>
            </div>
          </div>
          <Button onClick={handleDismiss} variant="ghost" size="sm" className="ml-2 p-1 h-auto">
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}
