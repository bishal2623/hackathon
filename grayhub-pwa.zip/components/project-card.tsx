"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Heart, Eye, Lock, Unlock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { PatentScoreMeter } from "./patent-score-meter"

interface ProjectCardProps {
  id: string
  title: string
  description: string
  author: string
  authorAvatar?: string
  image?: string
  patentScore: number
  category: string
  isPrivate?: boolean
  likes: number
  views: number
  price?: string
  blockchain?: "ethereum" | "polygon" | "optimism" | "arbitrum" | "base"
  isLiked?: boolean
  onLike?: () => void
}

const blockchainColors = {
  ethereum: "bg-blue-100 text-blue-800",
  polygon: "bg-purple-100 text-purple-800",
  optimism: "bg-red-100 text-red-800",
  arbitrum: "bg-blue-100 text-blue-800",
  base: "bg-indigo-100 text-indigo-800",
}

export function ProjectCard({
  id,
  title,
  description,
  author,
  authorAvatar,
  image,
  patentScore,
  category,
  isPrivate = false,
  likes,
  views,
  price,
  blockchain = "ethereum",
  isLiked = false,
  onLike,
}: ProjectCardProps) {
  const [liked, setLiked] = useState(isLiked)
  const [likeCount, setLikeCount] = useState(likes)

  const handleLike = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()

    setLiked(!liked)
    setLikeCount((prev) => (liked ? prev - 1 : prev + 1))
    onLike?.()
  }

  return (
    <div className="group bg-white rounded-xl border border-gray-200 overflow-hidden grayhub-card-glow">
      <Link href={`/projects/${id}`}>
        <div className="relative">
          {/* Project Image */}
          <div className="aspect-video bg-gradient-to-br from-gray-100 to-gray-200 relative overflow-hidden">
            {image ? (
              <Image
                src={image || "/placeholder.svg"}
                alt={title}
                fill
                className="object-cover group-hover:scale-105 transition-transform duration-300"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <div className="w-16 h-16 bg-gradient-to-br from-[#6C63FF] to-[#1E2A78] rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-xl">{title.charAt(0).toUpperCase()}</span>
                </div>
              </div>
            )}

            {/* Privacy Indicator */}
            <div className="absolute top-3 left-3">
              {isPrivate ? (
                <Badge variant="secondary" className="bg-red-100 text-red-800">
                  <Lock className="w-3 h-3 mr-1" />
                  Private
                </Badge>
              ) : (
                <Badge variant="secondary" className="bg-green-100 text-green-800">
                  <Unlock className="w-3 h-3 mr-1" />
                  Public
                </Badge>
              )}
            </div>

            {/* Blockchain Badge */}
            <div className="absolute top-3 right-3">
              <Badge className={blockchainColors[blockchain]}>
                {blockchain.charAt(0).toUpperCase() + blockchain.slice(1)}
              </Badge>
            </div>

            {/* Price */}
            {price && (
              <div className="absolute bottom-3 right-3 bg-black/80 text-white px-2 py-1 rounded-md text-sm font-medium">
                {price} ETH
              </div>
            )}
          </div>

          {/* Content */}
          <div className="p-4">
            {/* Category */}
            <Badge variant="outline" className="mb-2 text-[#6C63FF] border-[#6C63FF]">
              {category}
            </Badge>

            {/* Title */}
            <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2 group-hover:text-[#6C63FF] transition-colors">
              {title}
            </h3>

            {/* Description */}
            <p className="text-gray-600 text-sm mb-3 line-clamp-2">{description}</p>

            {/* Author */}
            <div className="flex items-center mb-3">
              <div className="w-6 h-6 bg-gradient-to-br from-[#6C63FF] to-[#1E2A78] rounded-full flex items-center justify-center mr-2">
                {authorAvatar ? (
                  <Image
                    src={authorAvatar || "/placeholder.svg"}
                    alt={author}
                    width={24}
                    height={24}
                    className="rounded-full"
                  />
                ) : (
                  <span className="text-white text-xs font-medium">{author.charAt(0).toUpperCase()}</span>
                )}
              </div>
              <span className="text-sm text-gray-700 font-medium">{author}</span>
            </div>

            {/* Patent Score */}
            <div className="mb-4">
              <PatentScoreMeter score={patentScore} size="sm" />
            </div>

            {/* Stats and Actions */}
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4 text-sm text-gray-500">
                <div className="flex items-center">
                  <Eye className="w-4 h-4 mr-1" />
                  {views}
                </div>
                <div className="flex items-center">
                  <Heart className={`w-4 h-4 mr-1 ${liked ? "fill-red-500 text-red-500" : ""}`} />
                  {likeCount}
                </div>
              </div>

              <Button variant="ghost" size="sm" onClick={handleLike} className="p-2 hover:bg-red-50">
                <Heart className={`w-4 h-4 ${liked ? "fill-red-500 text-red-500" : "text-gray-400"}`} />
              </Button>
            </div>
          </div>
        </div>
      </Link>
    </div>
  )
}
