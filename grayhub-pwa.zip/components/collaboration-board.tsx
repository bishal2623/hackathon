"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Plus, MoreHorizontal, Calendar, Flag } from "lucide-react"

interface Task {
  id: string
  title: string
  description: string
  assignee: string
  priority: "low" | "medium" | "high"
  dueDate: string
  status: "todo" | "in-progress" | "review" | "done"
}

interface CollaborationBoardProps {
  collaborationId: string
}

const mockTasks: Task[] = [
  {
    id: "1",
    title: "Design smart contract architecture",
    description: "Create the overall architecture for the voting smart contracts",
    assignee: "Alex Rodriguez",
    priority: "high",
    dueDate: "2024-02-20",
    status: "in-progress",
  },
  {
    id: "2",
    title: "Implement zero-knowledge proofs",
    description: "Research and implement ZK-SNARKs for voter privacy",
    assignee: "Maya Patel",
    priority: "high",
    dueDate: "2024-02-25",
    status: "todo",
  },
  {
    id: "3",
    title: "Create user interface mockups",
    description: "Design the voting interface and admin dashboard",
    assignee: "Sarah Chen",
    priority: "medium",
    dueDate: "2024-02-22",
    status: "review",
  },
  {
    id: "4",
    title: "Set up development environment",
    description: "Configure Hardhat, testing framework, and CI/CD",
    assignee: "Alex Rodriguez",
    priority: "medium",
    dueDate: "2024-02-15",
    status: "done",
  },
]

export function CollaborationBoard({ collaborationId }: CollaborationBoardProps) {
  const [tasks, setTasks] = useState(mockTasks)

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusTasks = (status: string) => {
    return tasks.filter((task) => task.status === status)
  }

  const columns = [
    { id: "todo", title: "To Do", tasks: getStatusTasks("todo") },
    { id: "in-progress", title: "In Progress", tasks: getStatusTasks("in-progress") },
    { id: "review", title: "Review", tasks: getStatusTasks("review") },
    { id: "done", title: "Done", tasks: getStatusTasks("done") },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Project Board</h2>
        <Button className="bg-[#6C63FF] text-white hover:bg-[#1E2A78]">
          <Plus className="w-4 h-4 mr-2" />
          Add Task
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {columns.map((column) => (
          <div key={column.id} className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-gray-900">{column.title}</h3>
              <Badge variant="outline">{column.tasks.length}</Badge>
            </div>

            <div className="space-y-3">
              {column.tasks.map((task) => (
                <Card key={task.id} className="grayhub-card-glow cursor-pointer hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <h4 className="font-medium text-gray-900 text-sm leading-tight">{task.title}</h4>
                      <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </div>

                    <p className="text-xs text-gray-600 mb-3 line-clamp-2">{task.description}</p>

                    <div className="flex items-center justify-between mb-3">
                      <Badge className={getPriorityColor(task.priority)}>
                        <Flag className="w-3 h-3 mr-1" />
                        {task.priority}
                      </Badge>
                      <div className="flex items-center text-xs text-gray-500">
                        <Calendar className="w-3 h-3 mr-1" />
                        {new Date(task.dueDate).toLocaleDateString()}
                      </div>
                    </div>

                    <div className="flex items-center">
                      <Avatar className="w-6 h-6">
                        <AvatarFallback className="bg-gradient-to-br from-[#6C63FF] to-[#1E2A78] text-white text-xs">
                          {task.assignee
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-xs text-gray-600 ml-2">{task.assignee}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}

              <Button
                variant="outline"
                className="w-full border-dashed border-gray-300 text-gray-500 hover:border-[#6C63FF] hover:text-[#6C63FF] bg-transparent"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Task
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
