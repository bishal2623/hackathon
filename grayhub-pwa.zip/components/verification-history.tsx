"use client"

import { motion } from "framer-motion"
import { FileText, Calendar, Download, Share, Trash2, Filter } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ConfidenceMeter } from "@/components/confidence-meter"
import { useState } from "react"

interface Verification {
  id: string
  fileName: string
  fileType: string
  result: "AUTHENTIC" | "FAKE" | "SUSPICIOUS"
  confidence: number
  timestamp: Date
  details: any
}

interface VerificationHistoryProps {
  verifications: Verification[]
}

export function VerificationHistory({ verifications }: VerificationHistoryProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState<string>("all")
  const [sortBy, setSortBy] = useState<string>("newest")

  const filteredVerifications = verifications
    .filter((v) => {
      const matchesSearch = v.fileName.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesStatus = filterStatus === "all" || v.result === filterStatus
      return matchesSearch && matchesStatus
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "newest":
          return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
        case "oldest":
          return new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
        case "confidence":
          return b.confidence - a.confidence
        case "name":
          return a.fileName.localeCompare(b.fileName)
        default:
          return 0
      }
    })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "AUTHENTIC":
        return "bg-emerald-100 text-emerald-800 border-emerald-200"
      case "FAKE":
        return "bg-red-100 text-red-800 border-red-200"
      case "SUSPICIOUS":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      default:
        return "bg-slate-100 text-slate-800 border-slate-200"
    }
  }

  if (verifications.length === 0) {
    return (
      <Card className="text-center py-12">
        <CardContent>
          <FileText className="h-12 w-12 text-slate-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-slate-600 mb-2">No Verifications Yet</h3>
          <p className="text-slate-500">Start verifying documents to see your history here</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filter & Search
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <Input
                placeholder="Search by filename..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="AUTHENTIC">Authentic</SelectItem>
                <SelectItem value="SUSPICIOUS">Suspicious</SelectItem>
                <SelectItem value="FAKE">Fake</SelectItem>
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest First</SelectItem>
                <SelectItem value="oldest">Oldest First</SelectItem>
                <SelectItem value="confidence">Confidence</SelectItem>
                <SelectItem value="name">Name</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      <div className="space-y-4">
        {filteredVerifications.map((verification, index) => (
          <motion.div
            key={verification.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row gap-6">
                  {/* File Info */}
                  <div className="flex-1 space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-slate-100 rounded-lg">
                          <FileText className="h-5 w-5 text-slate-600" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-slate-800 truncate">{verification.fileName}</h3>
                          <div className="flex items-center gap-2 text-sm text-slate-500">
                            <Calendar className="h-4 w-4" />
                            {verification.timestamp.toLocaleDateString()} at{" "}
                            {verification.timestamp.toLocaleTimeString()}
                          </div>
                        </div>
                      </div>
                      <Badge className={getStatusColor(verification.result)}>{verification.result}</Badge>
                    </div>

                    <div className="flex items-center gap-4 text-sm text-slate-600">
                      <span>File Type: {verification.fileType}</span>
                      <span>•</span>
                      <span>Confidence: {verification.confidence}%</span>
                    </div>
                  </div>

                  {/* Confidence Meter */}
                  <div className="flex-shrink-0 flex items-center">
                    <ConfidenceMeter confidence={verification.confidence} size="sm" showLabel={false} />
                  </div>

                  {/* Actions */}
                  <div className="flex-shrink-0 flex flex-col sm:flex-row gap-2">
                    <Button variant="outline" size="sm">
                      <Download className="h-4 w-4 mr-1" />
                      Report
                    </Button>
                    <Button variant="outline" size="sm">
                      <Share className="h-4 w-4 mr-1" />
                      Share
                    </Button>
                    <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700 bg-transparent">
                      <Trash2 className="h-4 w-4 mr-1" />
                      Delete
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {filteredVerifications.length === 0 && verifications.length > 0 && (
        <Card className="text-center py-8">
          <CardContent>
            <p className="text-slate-500">No verifications match your current filters</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
