"use client"

import { Progress } from "@/components/ui/progress"
import { TrendingUp, TrendingDown, Minus } from "lucide-react"

interface PatentScoreMeterProps {
  score: number
  trend?: "up" | "down" | "stable"
  trendValue?: number
  size?: "sm" | "md" | "lg"
  showDetails?: boolean
}

export function PatentScoreMeter({
  score,
  trend = "stable",
  trendValue = 0,
  size = "md",
  showDetails = true,
}: PatentScoreMeterProps) {
  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600"
    if (score >= 60) return "text-yellow-600"
    if (score >= 40) return "text-orange-600"
    return "text-red-600"
  }

  const getProgressColor = (score: number) => {
    if (score >= 80) return "bg-green-500"
    if (score >= 60) return "bg-yellow-500"
    if (score >= 40) return "bg-orange-500"
    return "bg-red-500"
  }

  const getTrendIcon = () => {
    switch (trend) {
      case "up":
        return <TrendingUp className="w-4 h-4 text-green-600" />
      case "down":
        return <TrendingDown className="w-4 h-4 text-red-600" />
      default:
        return <Minus className="w-4 h-4 text-gray-400" />
    }
  }

  const sizeClasses = {
    sm: "text-sm",
    md: "text-base",
    lg: "text-lg",
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <span className={`font-semibold ${sizeClasses[size]}`}>Patent Score</span>
          {showDetails && (
            <div className="flex items-center space-x-1">
              {getTrendIcon()}
              {trendValue !== 0 && (
                <span
                  className={`text-xs ${
                    trend === "up" ? "text-green-600" : trend === "down" ? "text-red-600" : "text-gray-500"
                  }`}
                >
                  {trend === "up" ? "+" : trend === "down" ? "-" : ""}
                  {Math.abs(trendValue)}
                </span>
              )}
            </div>
          )}
        </div>
        <span className={`font-bold ${sizeClasses[size]} ${getScoreColor(score)}`}>{score}/100</span>
      </div>

      <div className="relative">
        <Progress value={score} className="h-2 bg-gray-200" />
        <div
          className={`absolute top-0 left-0 h-2 rounded-full transition-all duration-500 ${getProgressColor(score)}`}
          style={{ width: `${score}%` }}
        />
      </div>

      {showDetails && size !== "sm" && (
        <div className="flex justify-between text-xs text-gray-500">
          <span>Low Risk</span>
          <span>Medium Risk</span>
          <span>High Potential</span>
        </div>
      )}
    </div>
  )
}
